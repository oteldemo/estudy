(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AUJA0QiSnVFuhYIAAPyQiSjZhKjsgA3ln5QCTDaBJDsQCTHWlvBWIAAvyg");
	this.shape.setTransform(151,50.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol26, new cjs.Rectangle(0,0,301.9,101.1), null);


(lib.Symbol25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("A3kH3IAAvtMAvJAAAIAAPtg");
	this.shape.setTransform(150.9,50.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18, new cjs.Rectangle(0,0,301.8,100.7), null);


(lib.Symbol14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF66").s().p("Ag6bMMAAAg2XIB1AAMAAAA2Xg");
	this.shape.setTransform(5.9,174);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14, new cjs.Rectangle(0,0,11.8,348), null);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF66").s().p("A7Lg5MA2XgABIAAB1Mg2XAAAg");
	this.shape.setTransform(174,5.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12, new cjs.Rectangle(0,0,348,11.8), null);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF66").s().p("A6/A9IAAh5MA1/AAAIAAB5g");
	this.shape.setTransform(172.8,6.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(0,0,345.6,12.2), null);


(lib.Symbol26copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AUJA0QiSnVFuhYIAAPyQiSjZhKjsgA3ln5QCTDaBJDsQCTHWlvBWIAAvyg");
	this.shape.setTransform(151,50.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol26copy3, new cjs.Rectangle(0,0,301.9,101.1), null);


(lib.Symbol26copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AUJA0QiSnVFuhYIAAPyQiSjZhKjsgA3ln5QCTDaBJDsQCTHWlvBWIAAvyg");
	this.shape.setTransform(151,50.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol26copy2, new cjs.Rectangle(0,0,301.9,101.1), null);


(lib.Symbol26copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("AUJA0QiSnVFuhYIAAPyQiSjZhKjsgA3ln5QCTDaBJDsQCTHWlvBWIAAvyg");
	this.shape.setTransform(151,50.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol26copy, new cjs.Rectangle(0,0,301.9,101.1), null);


(lib.Symbol26_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0099FF").s().p("AUJA0QiSnVFuhYIAAPyQiSjZhKjsgA3ln5QCTDaBJDsQCTHWlvBWIAAvyg");
	this.shape_1.setTransform(151,50.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol26_1, new cjs.Rectangle(0,0,301.9,101.1), null);


(lib.Symbol25copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol25copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol25copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol25_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol19copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol19copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol19copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol19_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol18copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("A3kH3IAAvtMAvJAAAIAAPtg");
	this.shape.setTransform(150.9,50.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18copy3, new cjs.Rectangle(0,0,301.8,100.7), null);


(lib.Symbol18copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("A3kH3IAAvtMAvJAAAIAAPtg");
	this.shape.setTransform(150.9,50.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18copy2, new cjs.Rectangle(0,0,301.8,100.7), null);


(lib.Symbol18copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("A3kH3IAAvtMAvJAAAIAAPtg");
	this.shape.setTransform(150.9,50.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18copy, new cjs.Rectangle(0,0,301.8,100.7), null);


(lib.Symbol18_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("A3kH3IAAvtMAvJAAAIAAPtg");
	this.shape_1.setTransform(150.9,50.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18_1, new cjs.Rectangle(0,0,301.8,100.7), null);


(lib.Symbol14copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF66").s().p("Ag6bMMAAAg2XIB1AAMAAAA2Xg");
	this.shape.setTransform(5.9,174);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14copy3, new cjs.Rectangle(0,0,11.8,348), null);


(lib.Symbol14copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF66").s().p("Ag6bMMAAAg2XIB1AAMAAAA2Xg");
	this.shape.setTransform(5.9,174);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14copy2, new cjs.Rectangle(0,0,11.8,348), null);


(lib.Symbol14copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF66").s().p("Ag6bMMAAAg2XIB1AAMAAAA2Xg");
	this.shape.setTransform(5.9,174);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14copy, new cjs.Rectangle(0,0,11.8,348), null);


(lib.Symbol14_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF66").s().p("Ag6bMMAAAg2XIB1AAMAAAA2Xg");
	this.shape_1.setTransform(5.9,174);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14_1, new cjs.Rectangle(0,0,11.8,348), null);


(lib.Symbol12copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF66").s().p("A7Lg5MA2XgABIAAB1Mg2XAAAg");
	this.shape.setTransform(174,5.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12copy3, new cjs.Rectangle(0,0,348,11.8), null);


(lib.Symbol12copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF66").s().p("A7Lg5MA2XgABIAAB1Mg2XAAAg");
	this.shape.setTransform(174,5.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12copy2, new cjs.Rectangle(0,0,348,11.8), null);


(lib.Symbol12copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF66").s().p("A7Lg5MA2XgABIAAB1Mg2XAAAg");
	this.shape.setTransform(174,5.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12copy, new cjs.Rectangle(0,0,348,11.8), null);


(lib.Symbol12_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF66").s().p("A7Lg5MA2XgABIAAB1Mg2XAAAg");
	this.shape_1.setTransform(174,5.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12_1, new cjs.Rectangle(0,0,348,11.8), null);


(lib.Symbol10copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF66").s().p("A6/A9IAAh5MA1/AAAIAAB5g");
	this.shape.setTransform(172.8,6.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10copy3, new cjs.Rectangle(0,0,345.6,12.2), null);


(lib.Symbol10copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF66").s().p("A6/A9IAAh5MA1/AAAIAAB5g");
	this.shape.setTransform(172.8,6.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10copy2, new cjs.Rectangle(0,0,345.6,12.2), null);


(lib.Symbol10copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF66").s().p("A6/A9IAAh5MA1/AAAIAAB5g");
	this.shape.setTransform(172.8,6.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10copy, new cjs.Rectangle(0,0,345.6,12.2), null);


(lib.Symbol10_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF66").s().p("A6/A9IAAh5MA1/AAAIAAB5g");
	this.shape_1.setTransform(172.8,6.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10_1, new cjs.Rectangle(0,0,345.6,12.2), null);


(lib.Symbol24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib.Symbol25();
	this.instance.parent = this;
	this.instance.setTransform(1,1.8,1,1,0,0,0,151,50.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:0,regY:0,x:-150,y:-48.8},0).wait(598));

	// Layer 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3WH5IAAvxMAutAAAIAAPxg");
	mask.setTransform(1,2);

	// Layer 1
	this.text = new cjs.Text("PD Website", "50px 'Tw Cen MT'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 56;
	this.text.lineWidth = 297;
	this.text.parent = this;
	this.text.setTransform(0.8,-27.2);

	var maskedShapeInstanceList = [this.text];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({y:-27.5},0).wait(1).to({y:-29.6},0).wait(1).to({y:-35.1},0).wait(1).to({y:-45.9},0).wait(1).to({y:-63.6},0).wait(1).to({y:-90},0).wait(1).to({y:-127},0).wait(1).to({y:-176.1},0).wait(1).to({y:-239.1},0).wait(1).to({y:-259.8},0).to({_off:true},1).wait(588));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-148.5,-29.2,299,58.5);


(lib.Symbol17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AzJA1IAAszMAmTAAAIAAMzg");
	mask.setTransform(0.2,-76.7);

	// Layer 3
	this.text = new cjs.Text("PD Website", "50px 'Tw Cen MT'", "#000099");
	this.text.textAlign = "center";
	this.text.lineHeight = 56;
	this.text.lineWidth = 305;
	this.text.parent = this;
	this.text.setTransform(3.3,-25.9);

	var maskedShapeInstanceList = [this.text];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({y:-41.4},0).wait(1).to({x:3.4,y:-56.9},0).wait(1).to({x:3.5,y:-72.4},0).wait(1).to({x:3.6,y:-87.8},0).wait(1).to({x:3.7,y:-103.2},0).wait(1).to({x:3.8,y:-118.5},0).wait(1).to({x:3.9,y:-133.7},0).wait(1).to({x:4,y:-145.3},0).wait(624));

	// Layer 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("A3kH8QCIkABEj+QCEnwlAgJMAu5AAAQhvD+g4D9QhvH6EWACg");
	var mask_1_graphics_1 = new cjs.Graphics().p("A3iH8QAxhQAnhRQAcg8AWg8QAnhwAahwQBsm0j0hFQgVgEgZgBMAuZAAAIAXABIgHANQgkBHgdBLQg/CngeCxQhXGvDNBKQATAFAWABg");
	var mask_1_graphics_2 = new cjs.Graphics().p("A3fH8QA1hLAohQQAeg7AUg9QAkhwAWhxQBfmjjqhbQgRgEgUgBMAuTAAAIATABIgHAMQgpBDgdBMQhACjgXC1QhKGdDJBhQAPAEATABg");
	var mask_1_graphics_3 = new cjs.Graphics().p("A3dH8QA6hHAphOQAgg7ASg9QAihvAShyQBRmUjghxQgNgDgPgBMAuPAAAIAOACIgIALQgsA+gfBMQg/CfgQC6Qg+GKDEB4QAMAEAPABg");
	var mask_1_graphics_4 = new cjs.Graphics().p("A3bH8QA/hDAqhMQAhg6ARg9QAehwAPhzQBFmEjYiGQgIgDgLgBMAuLAAAIAKACIgJAKQgwA7ggBLQhACbgIDAQgyF3DACPQAIADALABg");
	var mask_1_graphics_5 = new cjs.Graphics().p("A3ZH8QBDg/AshKQAjg6APg9QAbhwALhzQA4l1jOicQgEgCgGgBMAuGAAAIAFACIgKAKQg0A2ghBLQg/CXgCDFQglFkC8CmQADAEAHAAg");
	var mask_1_graphics_6 = new cjs.Graphics().p("A3XH8QBIg6AthJQAkg5AOg9QAYhwAGh1QAslljFixQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBgBAAMAuDAAAIAAADIgLAJQg4AxghBMQhACSAGDKQgZFSC4C9QgBAAAAABQAAABABAAQAAAAAAABQABAAAAAAg");
	var mask_1_graphics_7 = new cjs.Graphics().p("A3YH8QBMg2AuhHQAmg4ALg+QAWhwADh2QAdlVi6jGIAHgDMAt+AAAIgEADIgMAIQg7AtgjBMQhACOANDQQgNE+C0DUQgFADgDAAg");
	var mask_1_graphics_8 = new cjs.Graphics().p("A3bH8QBQgyAxhFQAng4AKg+QAShwgBh2QARlGixjcIAQgCMAt5AAAIgJAEIgMAHQhAAogjBMQhACLAUDUQAAErCvDsQgJACgIAAg");
	var mask_1_graphics_9 = new cjs.Graphics().p("A3dH8QBVguAxhDQApg3AIg+QAQhxgFh3QAEk2iojxIAZgCMAt0AAAQgGABgHADIgMAGQhEAlglBLQhACHAcDZQAMEZCqECIgZACg");
	var mask_1_graphics_10 = new cjs.Graphics().p("A3fH8QBZgqAyhBQArg3AHg+QAMhwgJh4QgJknidkHIAhgBMAtwAAAQgIABgKADIgNAGQhHAggnBLQhACDAjDfQAZEFClEaIgiABg");
	var mask_1_graphics_11 = new cjs.Graphics().p("A3iH8QBeglA0hAQAsg2AFg/QAJhwgMh5QgWkWiUkdIAqgBMAtrAAAIgWAFIgOAEQhMAcgmBMQhBB+AqDkQAmDzChEwIgsABg");
	var mask_1_graphics_12 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_13 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_14 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_15 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_16 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_17 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_18 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_19 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_20 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_21 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_22 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_23 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_24 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_25 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_26 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_27 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_28 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_29 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_30 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_31 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_32 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_33 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_34 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_35 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_36 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_37 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_38 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_39 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_40 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_41 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_42 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_43 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_44 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_45 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_46 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_47 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_48 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_49 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_50 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_51 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_52 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_53 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_54 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_55 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_56 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_57 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_58 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_59 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_60 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_61 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_62 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_63 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_64 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_65 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_67 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_68 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_70 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_71 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_72 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_73 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_74 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_75 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_76 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_77 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_78 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_79 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_80 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_81 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_82 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_83 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_84 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_85 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_86 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_87 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_88 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_89 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_90 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_91 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_92 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_93 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_94 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_95 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_96 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_97 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_98 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_99 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_100 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_101 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_102 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_103 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_104 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_105 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_106 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_107 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_108 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_109 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_110 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_111 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_112 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_113 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_114 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_115 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_116 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_117 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_118 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_119 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_120 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_121 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_122 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_123 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_124 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_125 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_126 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_127 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_128 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_129 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_130 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_131 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_132 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_133 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_134 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_135 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_136 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_137 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_138 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_139 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_140 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_141 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_142 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_143 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_144 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_145 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_146 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_147 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_148 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_149 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_150 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_151 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_152 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_153 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_154 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_155 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_156 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_157 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_158 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_159 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_160 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_161 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_162 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_163 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_164 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_165 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_166 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_167 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_168 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_169 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_170 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_171 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_172 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_173 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_174 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_175 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_176 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_177 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_178 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_179 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_180 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_181 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_182 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_183 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_184 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_185 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_186 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_187 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_188 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_189 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_190 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_191 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_192 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_193 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_194 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_195 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_196 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_197 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_198 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_199 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_200 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_201 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_202 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_203 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_204 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_205 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_206 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_207 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_208 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_209 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_210 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_211 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_212 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_213 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_214 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_215 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_216 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_217 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_218 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_219 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_220 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_221 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_222 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_223 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_224 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_225 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_226 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_227 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_228 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_229 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_230 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_231 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_232 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_233 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_234 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_235 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_236 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_237 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_238 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_239 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_240 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_241 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_242 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_243 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_244 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_245 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_246 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_247 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_248 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_249 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_250 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_251 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_252 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_253 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_254 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_255 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_256 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_257 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_258 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_259 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_260 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_261 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_262 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_263 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_264 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_265 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_266 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_267 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_268 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_269 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_270 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_271 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_272 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_273 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_274 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_275 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_276 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_277 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_278 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_279 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_280 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_281 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_282 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_283 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_284 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_285 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_286 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_287 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_288 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_289 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_290 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_291 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_292 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_293 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_294 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_295 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_296 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_297 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_298 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_299 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_300 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_301 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_302 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_303 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_304 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_305 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_306 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_307 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_308 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_309 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_310 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_311 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_312 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_313 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_314 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_315 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_316 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_317 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_318 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_319 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_320 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_321 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_322 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_323 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_324 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_325 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_326 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_327 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_328 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_329 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_330 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_331 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_332 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_333 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_334 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_335 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_336 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_337 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_338 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_339 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_340 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_341 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_342 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_343 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_344 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_345 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_346 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_347 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_348 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_349 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_350 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_351 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_352 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_353 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_354 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_355 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_356 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_357 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_358 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_359 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_360 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_361 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_362 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_363 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_364 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_365 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_366 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_367 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_368 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_369 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_370 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_371 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_372 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_373 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_374 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_375 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_376 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_377 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_378 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_379 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_380 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_381 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_382 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_383 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_384 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_385 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_386 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_387 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_388 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_389 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_390 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_391 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_392 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_393 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_394 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_395 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_396 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_397 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_398 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_399 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_400 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_401 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_402 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_403 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_404 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_405 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_406 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_407 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_408 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_409 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_410 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_411 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_412 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_413 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_414 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_415 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_416 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_417 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_418 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_419 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_420 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_421 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_422 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_423 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_424 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_425 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_426 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_427 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_428 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_429 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_430 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_431 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_432 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_433 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_434 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_435 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_436 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_437 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_438 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_439 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_440 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_441 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_442 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_443 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_444 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_445 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_446 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_447 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_448 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_449 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_450 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_451 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_452 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_453 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_454 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_455 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_456 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_457 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_458 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_459 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_460 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_461 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_462 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_463 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_464 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_465 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_466 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_467 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_468 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_469 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_470 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_471 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_472 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_473 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_474 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_475 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_476 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_477 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_478 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_479 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_480 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_481 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_482 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_483 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_484 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_485 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_486 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_487 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_488 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_489 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_490 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_491 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_492 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_493 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_494 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_495 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_496 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_497 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_498 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_499 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_500 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_501 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_502 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_503 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_504 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_505 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_506 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_507 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_508 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_509 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_510 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_511 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_512 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_513 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_514 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_515 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_516 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_517 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_518 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_519 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_520 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_521 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_522 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_523 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_524 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_525 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_526 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_527 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_528 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_529 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_530 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_531 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_532 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_533 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_534 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_535 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_536 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_537 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_538 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_539 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_540 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_541 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_542 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_543 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_544 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_545 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_546 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_547 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_548 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_549 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_550 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_551 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_552 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_553 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_554 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_555 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_556 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_557 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_558 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_559 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_560 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_561 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_562 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_563 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_564 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_565 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_566 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_567 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_568 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_569 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_570 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_571 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_572 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_573 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_574 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_575 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_576 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_577 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_578 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_579 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_580 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_581 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_582 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_583 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_584 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_585 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_586 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_587 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_588 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_589 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_590 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_591 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_592 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_593 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_594 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_595 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_596 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_597 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_598 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_599 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_600 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_601 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_602 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_603 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_604 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_605 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_606 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_607 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_608 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_609 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_610 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_611 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_612 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_613 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_614 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_615 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_616 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_617 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_618 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_619 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_620 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_621 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_622 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_623 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_624 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_625 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_626 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_627 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_628 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_629 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_630 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_631 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_1,x:-0.2,y:-121}).wait(1).to({graphics:mask_1_graphics_2,x:-0.4,y:-121}).wait(1).to({graphics:mask_1_graphics_3,x:-0.6,y:-121}).wait(1).to({graphics:mask_1_graphics_4,x:-0.9,y:-121}).wait(1).to({graphics:mask_1_graphics_5,x:-1.1,y:-121}).wait(1).to({graphics:mask_1_graphics_6,x:-1.2,y:-121}).wait(1).to({graphics:mask_1_graphics_7,x:-1.1,y:-121}).wait(1).to({graphics:mask_1_graphics_8,x:-0.8,y:-121}).wait(1).to({graphics:mask_1_graphics_9,x:-0.6,y:-121}).wait(1).to({graphics:mask_1_graphics_10,x:-0.4,y:-121}).wait(1).to({graphics:mask_1_graphics_11,x:-0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_12,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_13,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_14,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_15,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_16,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_17,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_18,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_19,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_20,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_21,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_22,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_23,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_24,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_25,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_26,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_27,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_28,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_29,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_30,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_31,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_32,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_33,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_34,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_35,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_36,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_37,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_38,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_39,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_40,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_41,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_42,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_43,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_44,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_45,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_46,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_47,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_48,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_49,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_50,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_51,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_52,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_53,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_54,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_55,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_56,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_57,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_58,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_59,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_60,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_61,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_62,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_63,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_64,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_65,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_66,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_67,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_68,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_69,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_70,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_71,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_72,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_73,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_74,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_75,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_76,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_77,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_78,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_79,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_80,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_81,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_82,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_83,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_84,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_85,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_86,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_87,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_88,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_89,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_90,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_91,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_92,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_93,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_94,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_95,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_96,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_97,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_98,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_99,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_100,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_101,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_102,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_103,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_104,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_105,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_106,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_107,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_108,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_109,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_110,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_111,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_112,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_113,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_114,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_115,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_116,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_117,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_118,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_119,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_120,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_121,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_122,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_123,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_124,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_125,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_126,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_127,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_128,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_129,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_130,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_131,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_132,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_133,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_134,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_135,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_136,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_137,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_138,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_139,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_140,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_141,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_142,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_143,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_144,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_145,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_146,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_147,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_148,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_149,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_150,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_151,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_152,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_153,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_154,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_155,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_156,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_157,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_158,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_159,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_160,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_161,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_162,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_163,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_164,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_165,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_166,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_167,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_168,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_169,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_170,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_171,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_172,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_173,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_174,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_175,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_176,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_177,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_178,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_179,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_180,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_181,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_182,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_183,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_184,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_185,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_186,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_187,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_188,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_189,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_190,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_191,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_192,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_193,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_194,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_195,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_196,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_197,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_198,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_199,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_200,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_201,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_202,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_203,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_204,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_205,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_206,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_207,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_208,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_209,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_210,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_211,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_212,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_213,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_214,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_215,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_216,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_217,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_218,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_219,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_220,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_221,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_222,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_223,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_224,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_225,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_226,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_227,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_228,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_229,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_230,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_231,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_232,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_233,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_234,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_235,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_236,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_237,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_238,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_239,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_240,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_241,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_242,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_243,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_244,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_245,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_246,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_247,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_248,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_249,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_250,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_251,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_252,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_253,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_254,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_255,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_256,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_257,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_258,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_259,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_260,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_261,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_262,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_263,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_264,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_265,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_266,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_267,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_268,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_269,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_270,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_271,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_272,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_273,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_274,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_275,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_276,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_277,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_278,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_279,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_280,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_281,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_282,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_283,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_284,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_285,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_286,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_287,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_288,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_289,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_290,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_291,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_292,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_293,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_294,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_295,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_296,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_297,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_298,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_299,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_300,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_301,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_302,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_303,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_304,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_305,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_306,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_307,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_308,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_309,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_310,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_311,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_312,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_313,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_314,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_315,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_316,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_317,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_318,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_319,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_320,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_321,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_322,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_323,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_324,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_325,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_326,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_327,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_328,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_329,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_330,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_331,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_332,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_333,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_334,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_335,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_336,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_337,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_338,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_339,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_340,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_341,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_342,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_343,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_344,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_345,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_346,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_347,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_348,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_349,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_350,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_351,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_352,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_353,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_354,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_355,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_356,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_357,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_358,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_359,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_360,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_361,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_362,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_363,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_364,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_365,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_366,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_367,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_368,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_369,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_370,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_371,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_372,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_373,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_374,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_375,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_376,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_377,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_378,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_379,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_380,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_381,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_382,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_383,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_384,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_385,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_386,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_387,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_388,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_389,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_390,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_391,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_392,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_393,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_394,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_395,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_396,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_397,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_398,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_399,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_400,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_401,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_402,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_403,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_404,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_405,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_406,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_407,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_408,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_409,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_410,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_411,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_412,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_413,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_414,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_415,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_416,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_417,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_418,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_419,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_420,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_421,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_422,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_423,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_424,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_425,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_426,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_427,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_428,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_429,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_430,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_431,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_432,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_433,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_434,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_435,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_436,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_437,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_438,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_439,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_440,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_441,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_442,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_443,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_444,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_445,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_446,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_447,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_448,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_449,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_450,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_451,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_452,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_453,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_454,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_455,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_456,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_457,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_458,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_459,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_460,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_461,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_462,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_463,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_464,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_465,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_466,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_467,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_468,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_469,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_470,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_471,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_472,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_473,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_474,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_475,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_476,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_477,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_478,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_479,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_480,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_481,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_482,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_483,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_484,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_485,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_486,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_487,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_488,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_489,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_490,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_491,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_492,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_493,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_494,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_495,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_496,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_497,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_498,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_499,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_500,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_501,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_502,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_503,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_504,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_505,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_506,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_507,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_508,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_509,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_510,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_511,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_512,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_513,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_514,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_515,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_516,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_517,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_518,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_519,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_520,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_521,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_522,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_523,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_524,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_525,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_526,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_527,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_528,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_529,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_530,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_531,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_532,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_533,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_534,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_535,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_536,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_537,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_538,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_539,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_540,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_541,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_542,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_543,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_544,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_545,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_546,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_547,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_548,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_549,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_550,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_551,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_552,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_553,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_554,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_555,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_556,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_557,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_558,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_559,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_560,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_561,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_562,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_563,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_564,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_565,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_566,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_567,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_568,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_569,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_570,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_571,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_572,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_573,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_574,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_575,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_576,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_577,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_578,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_579,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_580,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_581,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_582,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_583,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_584,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_585,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_586,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_587,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_588,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_589,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_590,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_591,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_592,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_593,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_594,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_595,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_596,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_597,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_598,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_599,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_600,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_601,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_602,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_603,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_604,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_605,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_606,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_607,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_608,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_609,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_610,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_611,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_612,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_613,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_614,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_615,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_616,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_617,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_618,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_619,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_620,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_621,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_622,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_623,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_624,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_625,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_626,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_627,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_628,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_629,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_630,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_631,x:0.1,y:-121}).wait(1));

	// Layer 1
	this.instance = new lib.Symbol18();
	this.instance.parent = this;
	this.instance.setTransform(-0.2,-0.1,1.037,1,0,0,0,146.8,50.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:150.9,scaleY:1,x:4,y:-11.1},0).wait(1).to({scaleY:1.01,y:-22.2},0).wait(1).to({scaleY:1.01,x:3.9,y:-33.3},0).wait(1).to({scaleY:1.02,y:-44.3},0).wait(1).to({scaleY:1.02,x:3.8,y:-55.4},0).wait(1).to({scaleY:1.02,y:-66.5},0).wait(1).to({scaleY:1.03,x:3.7,y:-77.6},0).wait(1).to({scaleY:1.03,y:-88.6},0).wait(1).to({scaleY:1.03,x:3.6,y:-99.7},0).wait(1).to({scaleY:1.04,y:-110.8},0).wait(1).to({scaleY:1.04,x:3.5,y:-121.9},0).wait(621));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol14();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1,0,0,0,5.9,174);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:-32.4},0).wait(1).to({y:-64.9},0).wait(1).to({y:-97.4},0).wait(1).to({y:-129.8},0).wait(1).to({y:-162.3},0).wait(1).to({y:-194.8},0).wait(1).to({y:-227.3},0).wait(1).to({y:-259.7},0).wait(1).to({y:-292.2},0).wait(1).to({x:-0.1,y:-324.7},0).wait(1).to({y:-357.1},0).wait(1).to({y:-389.6},0).wait(1).to({y:-422.1},0).wait(1).to({y:-454.6},0).wait(1).to({y:-487},0).wait(1).to({y:-519.5},0).wait(1).to({y:-552},0).wait(1).to({y:-584.4},0).wait(1).to({x:-0.2,y:-616.9},0).wait(1).to({y:-649.4},0).wait(1).to({y:-681.9},0).wait(1).to({y:-714.3},0).wait(1).to({y:-746.8},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.9,-174,11.8,348);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol12();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1,0,0,0,174,5.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:-42,y:0.2},0).wait(1).to({x:-84,y:0.4},0).wait(1).to({x:-126,y:0.5},0).wait(1).to({x:-168.1,y:0.7},0).wait(1).to({x:-210.1,y:0.8},0).wait(1).to({x:-252.1,y:1},0).wait(1).to({x:-294.2,y:1.1},0).wait(1).to({x:-336.2,y:1.3},0).wait(1).to({x:-378.2,y:1.4},0).wait(1).to({x:-420.3,y:1.6},0).wait(1).to({x:-462.4,y:1.7},0).wait(1).to({x:-504.4,y:1.9},0).wait(1).to({x:-546.4,y:2},0).wait(1).to({x:-588.4,y:2.2},0).wait(1).to({x:-630.5,y:2.3},0).wait(1).to({x:-672.5,y:2.5},0).wait(1).to({x:-714.6,y:2.6},0).wait(1).to({x:-756.6,y:2.8},0).wait(1).to({x:-798.7,y:2.9},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-174,-5.9,348,11.8);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol10();
	this.instance.parent = this;
	this.instance.setTransform(0,-0.1,1,1,0,0,0,172.8,6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:6.1,x:43,y:0},0).wait(1).to({x:86},0).wait(1).to({x:129},0).wait(1).to({x:172},0).wait(1).to({x:214.9},0).wait(1).to({x:257.9},0).wait(1).to({x:300.8},0).wait(1).to({x:343.9},0).wait(1).to({x:386.8},0).wait(1).to({x:429.8},0).wait(1).to({x:472.8},0).wait(1).to({x:515.8},0).wait(1).to({x:558.8},0).wait(1).to({x:601.7},0).wait(1).to({x:644.8},0).wait(1).to({x:687.7},0).wait(1).to({x:730.7},0).wait(1).to({x:773.7},0).wait(1).to({x:816.7},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-172.8,-6.1,345.6,12.1);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 6
	this.instance = new lib.Symbol26();
	this.instance.parent = this;
	this.instance.setTransform(0,0.1,1,1,0,0,0,151,50.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhKBMQgegfAAgtQAAgrAfgfQAegfArAAQAsAAAfAgQAfAfgBAyIirAAQAGAfAUAPQAUAOAWAAQAkAAAZgeIAfAXQgjAtg7AAQgsAAgegegAg9gZIB6AAQgVgpgoAAQgqAAgTApg");
	this.shape.setTransform(104.7,3.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYCCIAAihIgiAAIAAgoIAiAAIAAg6IApAAIAAA7IAqAAIAAAnIgqAAIAAChg");
	this.shape_1.setTransform(85.5,0.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgUCWIAAjIIApAAIAADIgAgWhdQgKgKAAgOQAAgNAKgJQAKgKAMAAQANAAAKAKQAKAJAAANQAAAOgKAKQgKAJgNAAQgMAAgKgJg");
	this.shape_2.setTransform(73.1,-1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhFBDIAigQQARARASAAQANAAAKgHQAKgIAAgJQAAgRghgNQgjgOgNgNQgOgNAAgVQAAgZATgRQATgQAcAAQAcAAAkAdIgdAZQgLgIgIgEQgIgEgLAAQgZAAAAATQAAAOAgANQAhANAOAOQAPAPAAAWQAAAagVATQgVASgcAAQgpAAgcgng");
	this.shape_3.setTransform(59.4,3.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgfCUQgWgNgMgWIAAArIgqAAIAAk8IAqAAIAACbQAbgtAxAAQAoAAAdAfQAcAeAAArQAAArgcAgQgdAgglAAQgXAAgWgNgAgzAHQgTAUgBAbQABAdATATQAVATAdAAQAZAAAUgTQATgUAAgcQAAgbgTgUQgVgTgaAAQgbAAgVATg");
	this.shape_4.setTransform(37.9,-1.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhKBMQgegfAAgtQAAgrAfgfQAegfArAAQAsAAAfAgQAfAfgBAyIirAAQAGAfAUAPQAUAOAWAAQAkAAAZgeIAfAXQgjAtg7AAQgsAAgegegAg9gZIB6AAQgVgpgoAAQgqAAgTApg");
	this.shape_5.setTransform(12,3.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AABg/IhkDmIiKlAIAsAAIBfDaIBjjmIBkDkIBdjYIAsAAIiJFAg");
	this.shape_6.setTransform(-21.5,-1.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ah9CbIAAk1IBLAAQBZgBArAwQAsAvAAA8QAAA9gtAvQgtAwhVgBgAhTByIADAAQAvAAAYgFQAXgEAVgPQAWgOANgYQAMgYAAgcQAAgjgUgdQgUgdgcgKQgcgKgvAAIgWAAg");
	this.shape_7.setTransform(-74.5,-1.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhZCbIAAk1IA+AAQA0AAAhAZQAgAZAAAnQAAAogiAaQgiAbhFgBIAACAgAgvgJQAvAAAXgNQAXgNAAgdQAAgVgSgQQgRgQg6gBg");
	this.shape_8.setTransform(-102.2,-1.6);

	this.instance_1 = new lib.Symbol19("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2.7,-3.2);

	this.instance_2 = new lib.Symbol24();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-1,-1.7);

	this.instance_3 = new lib.Symbol17();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-1.1,120.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A8WLGIAA2LMA4tAAAIAAWLg");
	mask.setTransform(-0.9,-0.2);

	// Layer 1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000099").s().p("A3lH6IAAvzMAvLAAAIAAPzg");

	this.instance_4 = new lib.Symbol13();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-176.4,381.6);

	this.instance_5 = new lib.Symbol11();
	this.instance_5.parent = this;
	this.instance_5.setTransform(399.7,64.9,1,1,-0.1,0,0,0.1,0.1);

	this.instance_6 = new lib.Symbol9();
	this.instance_6.parent = this;
	this.instance_6.setTransform(174.5,-295.2,1,1,90);

	this.instance_7 = new lib.Symbol9();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-399.1,-65.5);

	var maskedShapeInstanceList = [this.shape_9,this.instance_4,this.instance_5,this.instance_6,this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9}]}).to({state:[{t:this.shape_9},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-151,-50.5,302.1,101.1);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol6();
	this.instance.parent = this;
	this.instance.setTransform(0.1,-1.9);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(-182.3,-73.2,363,142), null);


(lib.Symbol24copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib.Symbol25copy3();
	this.instance.parent = this;
	this.instance.setTransform(1,1.8,1,1,0,0,0,151,50.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:0,regY:0,x:-150,y:-48.8},0).wait(598));

	// Layer 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3WH5IAAvxMAutAAAIAAPxg");
	mask.setTransform(1,2);

	// Layer 1
	this.text = new cjs.Text("Skills Map", "50px 'Tw Cen MT'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 56;
	this.text.lineWidth = 269;
	this.text.parent = this;
	this.text.setTransform(0.2,-27.1);

	var maskedShapeInstanceList = [this.text];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({y:-27.4},0).wait(1).to({y:-29.5},0).wait(1).to({y:-35},0).wait(1).to({y:-45.9},0).wait(1).to({y:-63.7},0).wait(1).to({y:-90.3},0).wait(1).to({y:-127.5},0).wait(1).to({y:-176.9},0).wait(1).to({y:-240.4},0).wait(1).to({y:-261.1},0).to({_off:true},1).wait(588));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-136.4,-29.1,273.3,58.5);


(lib.Symbol24copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib.Symbol25copy2();
	this.instance.parent = this;
	this.instance.setTransform(1,1.8,1,1,0,0,0,151,50.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:0,regY:0,x:-150,y:-48.8},0).wait(598));

	// Layer 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3WH5IAAvxMAutAAAIAAPxg");
	mask.setTransform(1,2);

	// Layer 1
	this.text = new cjs.Text("Foundation", "50px 'Tw Cen MT'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 56;
	this.text.lineWidth = 269;
	this.text.parent = this;
	this.text.setTransform(0.2,-27.1);

	var maskedShapeInstanceList = [this.text];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({y:-27.4},0).wait(1).to({y:-29.5},0).wait(1).to({y:-35},0).wait(1).to({y:-45.9},0).wait(1).to({y:-63.7},0).wait(1).to({y:-90.3},0).wait(1).to({y:-127.5},0).wait(1).to({y:-176.9},0).wait(1).to({y:-240.4},0).wait(1).to({y:-261.1},0).to({_off:true},1).wait(588));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-136.4,-29.1,273.3,58.5);


(lib.Symbol24copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib.Symbol25copy();
	this.instance.parent = this;
	this.instance.setTransform(1,1.8,1,1,0,0,0,151,50.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:0,regY:0,x:-150,y:-48.8},0).wait(598));

	// Layer 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3WH5IAAvxMAutAAAIAAPxg");
	mask.setTransform(1,2);

	// Layer 1
	this.text = new cjs.Text("Careers", "50px 'Tw Cen MT'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 56;
	this.text.lineWidth = 269;
	this.text.parent = this;
	this.text.setTransform(0.2,-27.1);

	var maskedShapeInstanceList = [this.text];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({y:-27.4},0).wait(1).to({y:-29.5},0).wait(1).to({y:-35},0).wait(1).to({y:-45.9},0).wait(1).to({y:-63.7},0).wait(1).to({y:-90.3},0).wait(1).to({y:-127.5},0).wait(1).to({y:-176.9},0).wait(1).to({y:-240.4},0).wait(1).to({y:-261.1},0).to({_off:true},1).wait(588));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-136.4,-29.1,273.3,58.5);


(lib.Symbol24_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance_1 = new lib.Symbol25_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1,1.8,1,1,0,0,0,151,50.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:0,regY:0,x:-150,y:-48.8},0).wait(598));

	// Layer 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A3WH5IAAvxMAutAAAIAAPxg");
	mask_1.setTransform(1,2);

	// Layer 1
	this.text_1 = new cjs.Text("ESS", "50px 'Tw Cen MT'", "#FFFFFF");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 56;
	this.text_1.lineWidth = 136;
	this.text_1.parent = this;
	this.text_1.setTransform(0,-27.2);

	var maskedShapeInstanceList = [this.text_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.text_1).wait(1).to({y:-27.5},0).wait(1).to({y:-29.6},0).wait(1).to({y:-35.1},0).wait(1).to({y:-46},0).wait(1).to({y:-63.8},0).wait(1).to({y:-90.4},0).wait(1).to({y:-127.6},0).wait(1).to({y:-177},0).wait(1).to({y:-240.5},0).wait(1).to({y:-261.2},0).to({_off:true},1).wait(588));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.1,-29.2,140.2,58.5);


(lib.Symbol17copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A2rGaIAAszMAtWAAAIAAMzg");
	mask.setTransform(0.2,-112.3);

	// Layer 3
	this.text = new cjs.Text("Skills Map", "50px 'Tw Cen MT'", "#000099");
	this.text.textAlign = "center";
	this.text.lineHeight = 56;
	this.text.lineWidth = 295;
	this.text.parent = this;
	this.text.setTransform(1.9,-25.9);

	var maskedShapeInstanceList = [this.text];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({y:-41.4},0).wait(1).to({x:2,y:-56.9},0).wait(1).to({x:2.1,y:-72.4},0).wait(1).to({x:2.2,y:-87.8},0).wait(1).to({x:2.3,y:-103.2},0).wait(1).to({x:2.4,y:-118.5},0).wait(1).to({x:2.5,y:-133.7},0).wait(1).to({x:2.6,y:-145.3},0).wait(624));

	// Layer 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("A3kH8QCIkABEj+QCEnwlAgJMAu5AAAQhvD+g4D9QhvH6EWACg");
	var mask_1_graphics_1 = new cjs.Graphics().p("A3iH8QAxhQAnhRQAcg8AWg8QAnhwAahwQBsm0j0hFQgVgEgZgBMAuZAAAIAXABIgHANQgkBHgdBLQg/CngeCxQhXGvDNBKQATAFAWABg");
	var mask_1_graphics_2 = new cjs.Graphics().p("A3fH8QA1hLAohQQAeg7AUg9QAkhwAWhxQBfmjjqhbQgRgEgUgBMAuTAAAIATABIgHAMQgpBDgdBMQhACjgXC1QhKGdDJBhQAPAEATABg");
	var mask_1_graphics_3 = new cjs.Graphics().p("A3dH8QA6hHAphOQAgg7ASg9QAihvAShyQBRmUjghxQgNgDgPgBMAuPAAAIAOACIgIALQgsA+gfBMQg/CfgQC6Qg+GKDEB4QAMAEAPABg");
	var mask_1_graphics_4 = new cjs.Graphics().p("A3bH8QA/hDAqhMQAhg6ARg9QAehwAPhzQBFmEjYiGQgIgDgLgBMAuLAAAIAKACIgJAKQgwA7ggBLQhACbgIDAQgyF3DACPQAIADALABg");
	var mask_1_graphics_5 = new cjs.Graphics().p("A3ZH8QBDg/AshKQAjg6APg9QAbhwALhzQA4l1jOicQgEgCgGgBMAuGAAAIAFACIgKAKQg0A2ghBLQg/CXgCDFQglFkC8CmQADAEAHAAg");
	var mask_1_graphics_6 = new cjs.Graphics().p("A3XH8QBIg6AthJQAkg5AOg9QAYhwAGh1QAslljFixQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBgBAAMAuDAAAIAAADIgLAJQg4AxghBMQhACSAGDKQgZFSC4C9QgBAAAAABQAAABABAAQAAAAAAABQABAAAAAAg");
	var mask_1_graphics_7 = new cjs.Graphics().p("A3YH8QBMg2AuhHQAmg4ALg+QAWhwADh2QAdlVi6jGIAHgDMAt+AAAIgEADIgMAIQg7AtgjBMQhACOANDQQgNE+C0DUQgFADgDAAg");
	var mask_1_graphics_8 = new cjs.Graphics().p("A3bH8QBQgyAxhFQAng4AKg+QAShwgBh2QARlGixjcIAQgCMAt5AAAIgJAEIgMAHQhAAogjBMQhACLAUDUQAAErCvDsQgJACgIAAg");
	var mask_1_graphics_9 = new cjs.Graphics().p("A3dH8QBVguAxhDQApg3AIg+QAQhxgFh3QAEk2iojxIAZgCMAt0AAAQgGABgHADIgMAGQhEAlglBLQhACHAcDZQAMEZCqECIgZACg");
	var mask_1_graphics_10 = new cjs.Graphics().p("A3fH8QBZgqAyhBQArg3AHg+QAMhwgJh4QgJknidkHIAhgBMAtwAAAQgIABgKADIgNAGQhHAggnBLQhACDAjDfQAZEFClEaIgiABg");
	var mask_1_graphics_11 = new cjs.Graphics().p("A3iH8QBeglA0hAQAsg2AFg/QAJhwgMh5QgWkWiUkdIAqgBMAtrAAAIgWAFIgOAEQhMAcgmBMQhBB+AqDkQAmDzChEwIgsABg");
	var mask_1_graphics_12 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_13 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_14 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_15 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_16 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_17 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_18 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_19 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_20 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_21 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_22 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_23 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_24 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_25 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_26 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_27 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_28 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_29 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_30 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_31 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_32 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_33 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_34 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_35 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_36 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_37 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_38 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_39 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_40 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_41 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_42 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_43 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_44 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_45 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_46 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_47 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_48 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_49 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_50 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_51 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_52 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_53 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_54 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_55 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_56 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_57 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_58 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_59 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_60 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_61 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_62 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_63 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_64 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_65 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_67 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_68 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_70 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_71 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_72 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_73 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_74 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_75 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_76 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_77 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_78 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_79 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_80 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_81 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_82 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_83 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_84 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_85 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_86 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_87 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_88 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_89 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_90 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_91 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_92 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_93 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_94 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_95 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_96 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_97 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_98 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_99 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_100 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_101 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_102 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_103 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_104 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_105 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_106 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_107 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_108 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_109 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_110 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_111 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_112 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_113 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_114 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_115 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_116 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_117 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_118 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_119 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_120 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_121 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_122 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_123 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_124 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_125 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_126 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_127 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_128 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_129 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_130 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_131 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_132 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_133 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_134 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_135 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_136 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_137 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_138 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_139 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_140 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_141 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_142 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_143 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_144 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_145 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_146 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_147 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_148 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_149 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_150 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_151 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_152 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_153 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_154 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_155 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_156 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_157 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_158 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_159 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_160 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_161 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_162 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_163 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_164 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_165 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_166 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_167 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_168 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_169 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_170 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_171 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_172 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_173 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_174 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_175 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_176 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_177 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_178 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_179 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_180 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_181 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_182 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_183 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_184 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_185 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_186 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_187 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_188 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_189 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_190 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_191 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_192 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_193 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_194 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_195 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_196 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_197 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_198 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_199 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_200 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_201 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_202 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_203 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_204 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_205 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_206 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_207 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_208 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_209 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_210 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_211 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_212 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_213 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_214 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_215 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_216 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_217 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_218 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_219 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_220 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_221 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_222 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_223 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_224 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_225 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_226 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_227 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_228 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_229 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_230 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_231 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_232 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_233 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_234 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_235 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_236 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_237 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_238 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_239 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_240 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_241 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_242 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_243 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_244 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_245 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_246 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_247 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_248 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_249 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_250 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_251 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_252 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_253 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_254 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_255 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_256 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_257 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_258 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_259 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_260 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_261 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_262 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_263 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_264 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_265 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_266 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_267 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_268 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_269 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_270 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_271 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_272 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_273 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_274 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_275 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_276 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_277 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_278 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_279 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_280 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_281 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_282 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_283 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_284 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_285 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_286 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_287 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_288 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_289 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_290 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_291 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_292 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_293 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_294 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_295 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_296 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_297 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_298 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_299 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_300 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_301 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_302 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_303 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_304 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_305 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_306 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_307 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_308 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_309 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_310 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_311 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_312 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_313 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_314 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_315 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_316 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_317 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_318 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_319 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_320 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_321 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_322 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_323 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_324 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_325 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_326 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_327 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_328 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_329 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_330 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_331 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_332 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_333 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_334 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_335 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_336 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_337 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_338 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_339 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_340 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_341 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_342 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_343 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_344 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_345 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_346 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_347 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_348 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_349 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_350 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_351 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_352 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_353 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_354 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_355 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_356 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_357 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_358 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_359 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_360 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_361 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_362 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_363 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_364 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_365 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_366 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_367 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_368 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_369 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_370 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_371 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_372 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_373 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_374 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_375 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_376 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_377 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_378 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_379 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_380 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_381 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_382 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_383 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_384 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_385 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_386 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_387 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_388 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_389 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_390 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_391 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_392 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_393 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_394 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_395 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_396 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_397 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_398 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_399 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_400 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_401 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_402 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_403 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_404 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_405 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_406 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_407 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_408 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_409 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_410 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_411 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_412 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_413 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_414 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_415 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_416 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_417 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_418 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_419 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_420 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_421 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_422 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_423 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_424 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_425 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_426 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_427 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_428 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_429 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_430 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_431 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_432 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_433 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_434 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_435 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_436 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_437 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_438 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_439 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_440 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_441 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_442 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_443 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_444 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_445 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_446 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_447 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_448 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_449 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_450 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_451 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_452 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_453 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_454 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_455 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_456 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_457 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_458 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_459 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_460 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_461 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_462 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_463 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_464 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_465 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_466 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_467 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_468 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_469 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_470 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_471 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_472 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_473 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_474 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_475 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_476 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_477 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_478 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_479 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_480 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_481 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_482 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_483 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_484 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_485 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_486 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_487 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_488 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_489 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_490 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_491 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_492 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_493 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_494 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_495 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_496 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_497 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_498 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_499 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_500 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_501 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_502 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_503 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_504 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_505 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_506 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_507 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_508 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_509 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_510 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_511 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_512 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_513 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_514 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_515 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_516 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_517 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_518 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_519 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_520 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_521 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_522 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_523 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_524 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_525 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_526 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_527 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_528 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_529 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_530 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_531 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_532 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_533 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_534 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_535 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_536 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_537 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_538 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_539 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_540 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_541 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_542 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_543 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_544 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_545 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_546 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_547 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_548 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_549 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_550 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_551 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_552 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_553 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_554 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_555 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_556 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_557 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_558 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_559 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_560 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_561 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_562 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_563 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_564 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_565 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_566 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_567 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_568 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_569 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_570 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_571 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_572 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_573 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_574 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_575 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_576 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_577 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_578 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_579 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_580 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_581 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_582 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_583 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_584 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_585 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_586 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_587 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_588 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_589 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_590 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_591 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_592 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_593 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_594 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_595 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_596 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_597 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_598 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_599 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_600 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_601 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_602 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_603 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_604 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_605 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_606 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_607 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_608 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_609 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_610 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_611 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_612 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_613 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_614 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_615 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_616 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_617 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_618 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_619 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_620 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_621 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_622 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_623 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_624 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_625 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_626 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_627 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_628 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_629 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_630 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_631 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_1,x:-0.2,y:-121}).wait(1).to({graphics:mask_1_graphics_2,x:-0.4,y:-121}).wait(1).to({graphics:mask_1_graphics_3,x:-0.6,y:-121}).wait(1).to({graphics:mask_1_graphics_4,x:-0.9,y:-121}).wait(1).to({graphics:mask_1_graphics_5,x:-1.1,y:-121}).wait(1).to({graphics:mask_1_graphics_6,x:-1.2,y:-121}).wait(1).to({graphics:mask_1_graphics_7,x:-1.1,y:-121}).wait(1).to({graphics:mask_1_graphics_8,x:-0.8,y:-121}).wait(1).to({graphics:mask_1_graphics_9,x:-0.6,y:-121}).wait(1).to({graphics:mask_1_graphics_10,x:-0.4,y:-121}).wait(1).to({graphics:mask_1_graphics_11,x:-0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_12,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_13,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_14,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_15,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_16,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_17,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_18,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_19,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_20,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_21,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_22,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_23,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_24,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_25,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_26,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_27,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_28,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_29,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_30,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_31,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_32,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_33,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_34,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_35,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_36,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_37,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_38,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_39,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_40,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_41,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_42,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_43,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_44,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_45,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_46,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_47,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_48,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_49,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_50,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_51,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_52,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_53,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_54,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_55,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_56,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_57,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_58,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_59,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_60,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_61,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_62,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_63,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_64,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_65,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_66,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_67,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_68,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_69,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_70,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_71,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_72,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_73,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_74,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_75,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_76,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_77,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_78,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_79,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_80,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_81,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_82,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_83,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_84,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_85,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_86,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_87,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_88,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_89,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_90,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_91,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_92,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_93,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_94,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_95,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_96,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_97,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_98,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_99,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_100,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_101,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_102,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_103,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_104,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_105,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_106,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_107,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_108,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_109,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_110,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_111,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_112,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_113,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_114,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_115,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_116,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_117,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_118,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_119,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_120,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_121,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_122,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_123,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_124,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_125,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_126,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_127,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_128,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_129,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_130,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_131,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_132,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_133,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_134,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_135,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_136,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_137,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_138,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_139,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_140,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_141,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_142,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_143,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_144,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_145,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_146,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_147,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_148,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_149,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_150,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_151,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_152,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_153,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_154,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_155,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_156,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_157,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_158,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_159,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_160,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_161,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_162,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_163,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_164,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_165,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_166,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_167,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_168,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_169,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_170,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_171,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_172,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_173,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_174,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_175,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_176,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_177,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_178,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_179,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_180,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_181,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_182,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_183,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_184,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_185,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_186,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_187,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_188,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_189,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_190,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_191,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_192,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_193,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_194,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_195,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_196,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_197,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_198,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_199,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_200,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_201,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_202,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_203,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_204,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_205,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_206,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_207,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_208,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_209,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_210,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_211,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_212,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_213,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_214,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_215,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_216,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_217,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_218,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_219,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_220,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_221,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_222,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_223,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_224,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_225,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_226,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_227,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_228,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_229,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_230,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_231,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_232,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_233,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_234,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_235,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_236,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_237,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_238,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_239,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_240,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_241,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_242,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_243,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_244,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_245,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_246,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_247,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_248,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_249,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_250,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_251,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_252,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_253,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_254,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_255,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_256,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_257,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_258,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_259,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_260,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_261,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_262,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_263,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_264,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_265,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_266,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_267,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_268,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_269,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_270,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_271,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_272,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_273,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_274,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_275,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_276,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_277,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_278,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_279,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_280,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_281,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_282,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_283,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_284,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_285,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_286,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_287,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_288,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_289,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_290,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_291,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_292,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_293,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_294,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_295,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_296,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_297,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_298,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_299,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_300,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_301,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_302,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_303,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_304,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_305,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_306,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_307,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_308,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_309,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_310,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_311,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_312,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_313,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_314,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_315,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_316,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_317,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_318,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_319,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_320,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_321,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_322,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_323,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_324,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_325,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_326,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_327,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_328,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_329,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_330,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_331,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_332,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_333,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_334,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_335,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_336,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_337,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_338,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_339,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_340,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_341,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_342,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_343,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_344,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_345,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_346,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_347,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_348,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_349,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_350,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_351,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_352,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_353,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_354,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_355,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_356,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_357,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_358,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_359,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_360,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_361,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_362,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_363,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_364,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_365,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_366,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_367,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_368,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_369,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_370,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_371,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_372,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_373,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_374,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_375,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_376,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_377,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_378,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_379,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_380,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_381,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_382,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_383,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_384,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_385,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_386,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_387,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_388,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_389,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_390,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_391,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_392,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_393,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_394,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_395,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_396,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_397,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_398,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_399,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_400,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_401,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_402,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_403,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_404,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_405,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_406,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_407,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_408,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_409,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_410,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_411,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_412,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_413,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_414,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_415,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_416,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_417,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_418,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_419,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_420,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_421,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_422,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_423,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_424,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_425,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_426,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_427,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_428,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_429,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_430,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_431,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_432,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_433,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_434,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_435,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_436,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_437,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_438,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_439,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_440,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_441,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_442,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_443,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_444,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_445,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_446,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_447,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_448,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_449,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_450,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_451,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_452,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_453,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_454,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_455,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_456,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_457,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_458,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_459,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_460,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_461,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_462,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_463,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_464,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_465,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_466,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_467,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_468,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_469,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_470,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_471,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_472,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_473,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_474,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_475,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_476,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_477,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_478,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_479,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_480,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_481,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_482,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_483,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_484,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_485,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_486,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_487,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_488,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_489,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_490,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_491,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_492,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_493,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_494,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_495,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_496,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_497,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_498,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_499,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_500,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_501,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_502,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_503,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_504,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_505,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_506,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_507,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_508,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_509,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_510,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_511,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_512,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_513,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_514,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_515,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_516,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_517,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_518,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_519,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_520,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_521,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_522,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_523,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_524,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_525,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_526,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_527,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_528,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_529,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_530,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_531,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_532,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_533,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_534,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_535,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_536,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_537,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_538,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_539,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_540,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_541,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_542,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_543,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_544,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_545,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_546,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_547,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_548,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_549,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_550,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_551,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_552,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_553,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_554,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_555,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_556,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_557,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_558,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_559,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_560,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_561,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_562,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_563,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_564,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_565,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_566,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_567,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_568,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_569,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_570,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_571,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_572,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_573,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_574,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_575,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_576,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_577,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_578,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_579,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_580,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_581,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_582,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_583,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_584,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_585,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_586,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_587,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_588,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_589,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_590,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_591,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_592,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_593,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_594,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_595,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_596,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_597,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_598,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_599,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_600,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_601,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_602,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_603,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_604,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_605,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_606,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_607,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_608,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_609,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_610,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_611,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_612,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_613,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_614,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_615,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_616,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_617,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_618,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_619,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_620,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_621,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_622,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_623,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_624,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_625,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_626,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_627,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_628,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_629,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_630,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_631,x:0.1,y:-121}).wait(1));

	// Layer 1
	this.instance = new lib.Symbol18copy3();
	this.instance.parent = this;
	this.instance.setTransform(-0.2,-0.1,1.037,1,0,0,0,146.7,50.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:150.9,scaleY:1,x:4.1,y:-11.1},0).wait(1).to({scaleY:1.01,y:-22.2},0).wait(1).to({scaleY:1.01,x:4,y:-33.3},0).wait(1).to({scaleY:1.02,y:-44.3},0).wait(1).to({scaleY:1.02,x:3.9,y:-55.4},0).wait(1).to({scaleY:1.02,y:-66.5},0).wait(1).to({scaleY:1.03,x:3.8,y:-77.6},0).wait(1).to({scaleY:1.03,y:-88.6},0).wait(1).to({scaleY:1.03,x:3.7,y:-99.7},0).wait(1).to({scaleY:1.04,y:-110.8},0).wait(1).to({scaleY:1.04,x:3.6,y:-121.9},0).wait(621));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol17copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A2rGaIAAszMAtWAAAIAAMzg");
	mask.setTransform(0.2,-112.3);

	// Layer 3
	this.text = new cjs.Text("Foundation", "50px 'Tw Cen MT'", "#000099");
	this.text.textAlign = "center";
	this.text.lineHeight = 56;
	this.text.lineWidth = 295;
	this.text.parent = this;
	this.text.setTransform(1.9,-25.9);

	var maskedShapeInstanceList = [this.text];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({y:-41.4},0).wait(1).to({x:2,y:-56.9},0).wait(1).to({x:2.1,y:-72.4},0).wait(1).to({x:2.2,y:-87.8},0).wait(1).to({x:2.3,y:-103.2},0).wait(1).to({x:2.4,y:-118.5},0).wait(1).to({x:2.5,y:-133.7},0).wait(1).to({x:2.6,y:-145.3},0).wait(624));

	// Layer 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("A3kH8QCIkABEj+QCEnwlAgJMAu5AAAQhvD+g4D9QhvH6EWACg");
	var mask_1_graphics_1 = new cjs.Graphics().p("A3iH8QAxhQAnhRQAcg8AWg8QAnhwAahwQBsm0j0hFQgVgEgZgBMAuZAAAIAXABIgHANQgkBHgdBLQg/CngeCxQhXGvDNBKQATAFAWABg");
	var mask_1_graphics_2 = new cjs.Graphics().p("A3fH8QA1hLAohQQAeg7AUg9QAkhwAWhxQBfmjjqhbQgRgEgUgBMAuTAAAIATABIgHAMQgpBDgdBMQhACjgXC1QhKGdDJBhQAPAEATABg");
	var mask_1_graphics_3 = new cjs.Graphics().p("A3dH8QA6hHAphOQAgg7ASg9QAihvAShyQBRmUjghxQgNgDgPgBMAuPAAAIAOACIgIALQgsA+gfBMQg/CfgQC6Qg+GKDEB4QAMAEAPABg");
	var mask_1_graphics_4 = new cjs.Graphics().p("A3bH8QA/hDAqhMQAhg6ARg9QAehwAPhzQBFmEjYiGQgIgDgLgBMAuLAAAIAKACIgJAKQgwA7ggBLQhACbgIDAQgyF3DACPQAIADALABg");
	var mask_1_graphics_5 = new cjs.Graphics().p("A3ZH8QBDg/AshKQAjg6APg9QAbhwALhzQA4l1jOicQgEgCgGgBMAuGAAAIAFACIgKAKQg0A2ghBLQg/CXgCDFQglFkC8CmQADAEAHAAg");
	var mask_1_graphics_6 = new cjs.Graphics().p("A3XH8QBIg6AthJQAkg5AOg9QAYhwAGh1QAslljFixQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBgBAAMAuDAAAIAAADIgLAJQg4AxghBMQhACSAGDKQgZFSC4C9QgBAAAAABQAAABABAAQAAAAAAABQABAAAAAAg");
	var mask_1_graphics_7 = new cjs.Graphics().p("A3YH8QBMg2AuhHQAmg4ALg+QAWhwADh2QAdlVi6jGIAHgDMAt+AAAIgEADIgMAIQg7AtgjBMQhACOANDQQgNE+C0DUQgFADgDAAg");
	var mask_1_graphics_8 = new cjs.Graphics().p("A3bH8QBQgyAxhFQAng4AKg+QAShwgBh2QARlGixjcIAQgCMAt5AAAIgJAEIgMAHQhAAogjBMQhACLAUDUQAAErCvDsQgJACgIAAg");
	var mask_1_graphics_9 = new cjs.Graphics().p("A3dH8QBVguAxhDQApg3AIg+QAQhxgFh3QAEk2iojxIAZgCMAt0AAAQgGABgHADIgMAGQhEAlglBLQhACHAcDZQAMEZCqECIgZACg");
	var mask_1_graphics_10 = new cjs.Graphics().p("A3fH8QBZgqAyhBQArg3AHg+QAMhwgJh4QgJknidkHIAhgBMAtwAAAQgIABgKADIgNAGQhHAggnBLQhACDAjDfQAZEFClEaIgiABg");
	var mask_1_graphics_11 = new cjs.Graphics().p("A3iH8QBeglA0hAQAsg2AFg/QAJhwgMh5QgWkWiUkdIAqgBMAtrAAAIgWAFIgOAEQhMAcgmBMQhBB+AqDkQAmDzChEwIgsABg");
	var mask_1_graphics_12 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_13 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_14 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_15 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_16 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_17 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_18 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_19 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_20 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_21 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_22 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_23 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_24 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_25 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_26 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_27 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_28 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_29 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_30 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_31 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_32 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_33 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_34 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_35 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_36 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_37 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_38 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_39 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_40 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_41 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_42 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_43 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_44 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_45 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_46 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_47 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_48 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_49 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_50 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_51 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_52 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_53 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_54 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_55 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_56 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_57 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_58 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_59 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_60 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_61 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_62 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_63 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_64 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_65 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_67 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_68 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_70 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_71 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_72 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_73 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_74 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_75 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_76 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_77 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_78 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_79 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_80 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_81 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_82 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_83 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_84 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_85 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_86 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_87 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_88 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_89 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_90 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_91 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_92 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_93 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_94 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_95 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_96 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_97 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_98 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_99 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_100 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_101 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_102 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_103 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_104 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_105 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_106 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_107 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_108 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_109 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_110 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_111 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_112 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_113 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_114 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_115 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_116 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_117 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_118 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_119 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_120 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_121 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_122 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_123 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_124 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_125 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_126 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_127 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_128 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_129 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_130 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_131 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_132 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_133 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_134 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_135 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_136 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_137 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_138 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_139 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_140 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_141 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_142 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_143 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_144 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_145 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_146 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_147 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_148 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_149 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_150 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_151 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_152 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_153 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_154 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_155 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_156 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_157 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_158 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_159 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_160 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_161 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_162 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_163 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_164 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_165 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_166 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_167 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_168 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_169 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_170 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_171 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_172 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_173 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_174 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_175 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_176 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_177 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_178 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_179 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_180 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_181 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_182 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_183 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_184 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_185 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_186 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_187 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_188 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_189 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_190 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_191 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_192 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_193 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_194 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_195 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_196 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_197 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_198 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_199 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_200 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_201 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_202 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_203 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_204 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_205 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_206 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_207 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_208 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_209 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_210 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_211 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_212 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_213 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_214 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_215 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_216 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_217 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_218 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_219 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_220 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_221 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_222 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_223 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_224 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_225 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_226 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_227 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_228 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_229 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_230 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_231 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_232 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_233 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_234 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_235 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_236 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_237 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_238 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_239 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_240 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_241 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_242 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_243 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_244 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_245 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_246 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_247 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_248 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_249 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_250 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_251 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_252 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_253 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_254 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_255 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_256 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_257 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_258 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_259 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_260 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_261 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_262 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_263 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_264 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_265 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_266 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_267 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_268 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_269 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_270 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_271 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_272 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_273 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_274 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_275 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_276 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_277 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_278 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_279 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_280 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_281 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_282 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_283 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_284 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_285 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_286 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_287 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_288 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_289 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_290 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_291 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_292 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_293 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_294 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_295 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_296 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_297 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_298 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_299 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_300 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_301 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_302 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_303 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_304 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_305 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_306 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_307 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_308 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_309 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_310 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_311 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_312 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_313 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_314 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_315 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_316 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_317 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_318 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_319 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_320 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_321 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_322 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_323 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_324 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_325 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_326 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_327 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_328 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_329 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_330 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_331 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_332 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_333 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_334 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_335 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_336 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_337 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_338 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_339 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_340 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_341 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_342 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_343 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_344 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_345 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_346 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_347 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_348 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_349 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_350 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_351 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_352 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_353 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_354 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_355 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_356 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_357 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_358 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_359 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_360 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_361 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_362 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_363 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_364 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_365 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_366 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_367 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_368 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_369 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_370 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_371 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_372 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_373 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_374 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_375 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_376 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_377 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_378 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_379 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_380 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_381 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_382 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_383 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_384 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_385 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_386 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_387 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_388 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_389 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_390 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_391 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_392 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_393 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_394 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_395 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_396 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_397 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_398 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_399 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_400 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_401 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_402 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_403 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_404 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_405 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_406 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_407 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_408 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_409 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_410 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_411 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_412 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_413 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_414 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_415 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_416 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_417 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_418 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_419 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_420 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_421 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_422 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_423 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_424 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_425 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_426 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_427 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_428 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_429 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_430 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_431 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_432 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_433 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_434 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_435 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_436 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_437 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_438 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_439 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_440 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_441 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_442 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_443 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_444 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_445 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_446 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_447 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_448 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_449 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_450 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_451 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_452 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_453 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_454 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_455 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_456 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_457 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_458 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_459 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_460 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_461 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_462 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_463 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_464 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_465 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_466 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_467 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_468 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_469 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_470 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_471 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_472 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_473 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_474 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_475 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_476 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_477 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_478 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_479 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_480 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_481 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_482 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_483 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_484 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_485 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_486 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_487 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_488 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_489 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_490 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_491 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_492 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_493 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_494 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_495 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_496 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_497 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_498 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_499 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_500 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_501 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_502 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_503 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_504 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_505 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_506 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_507 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_508 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_509 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_510 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_511 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_512 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_513 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_514 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_515 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_516 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_517 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_518 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_519 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_520 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_521 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_522 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_523 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_524 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_525 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_526 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_527 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_528 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_529 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_530 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_531 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_532 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_533 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_534 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_535 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_536 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_537 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_538 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_539 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_540 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_541 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_542 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_543 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_544 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_545 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_546 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_547 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_548 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_549 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_550 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_551 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_552 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_553 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_554 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_555 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_556 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_557 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_558 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_559 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_560 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_561 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_562 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_563 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_564 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_565 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_566 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_567 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_568 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_569 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_570 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_571 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_572 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_573 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_574 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_575 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_576 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_577 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_578 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_579 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_580 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_581 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_582 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_583 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_584 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_585 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_586 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_587 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_588 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_589 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_590 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_591 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_592 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_593 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_594 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_595 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_596 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_597 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_598 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_599 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_600 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_601 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_602 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_603 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_604 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_605 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_606 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_607 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_608 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_609 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_610 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_611 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_612 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_613 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_614 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_615 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_616 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_617 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_618 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_619 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_620 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_621 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_622 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_623 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_624 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_625 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_626 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_627 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_628 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_629 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_630 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_631 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_1,x:-0.2,y:-121}).wait(1).to({graphics:mask_1_graphics_2,x:-0.4,y:-121}).wait(1).to({graphics:mask_1_graphics_3,x:-0.6,y:-121}).wait(1).to({graphics:mask_1_graphics_4,x:-0.9,y:-121}).wait(1).to({graphics:mask_1_graphics_5,x:-1.1,y:-121}).wait(1).to({graphics:mask_1_graphics_6,x:-1.2,y:-121}).wait(1).to({graphics:mask_1_graphics_7,x:-1.1,y:-121}).wait(1).to({graphics:mask_1_graphics_8,x:-0.8,y:-121}).wait(1).to({graphics:mask_1_graphics_9,x:-0.6,y:-121}).wait(1).to({graphics:mask_1_graphics_10,x:-0.4,y:-121}).wait(1).to({graphics:mask_1_graphics_11,x:-0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_12,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_13,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_14,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_15,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_16,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_17,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_18,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_19,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_20,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_21,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_22,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_23,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_24,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_25,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_26,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_27,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_28,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_29,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_30,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_31,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_32,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_33,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_34,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_35,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_36,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_37,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_38,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_39,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_40,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_41,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_42,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_43,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_44,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_45,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_46,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_47,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_48,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_49,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_50,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_51,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_52,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_53,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_54,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_55,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_56,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_57,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_58,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_59,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_60,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_61,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_62,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_63,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_64,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_65,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_66,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_67,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_68,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_69,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_70,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_71,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_72,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_73,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_74,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_75,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_76,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_77,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_78,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_79,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_80,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_81,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_82,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_83,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_84,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_85,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_86,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_87,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_88,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_89,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_90,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_91,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_92,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_93,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_94,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_95,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_96,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_97,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_98,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_99,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_100,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_101,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_102,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_103,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_104,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_105,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_106,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_107,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_108,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_109,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_110,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_111,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_112,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_113,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_114,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_115,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_116,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_117,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_118,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_119,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_120,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_121,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_122,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_123,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_124,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_125,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_126,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_127,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_128,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_129,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_130,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_131,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_132,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_133,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_134,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_135,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_136,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_137,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_138,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_139,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_140,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_141,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_142,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_143,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_144,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_145,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_146,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_147,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_148,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_149,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_150,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_151,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_152,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_153,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_154,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_155,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_156,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_157,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_158,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_159,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_160,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_161,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_162,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_163,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_164,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_165,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_166,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_167,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_168,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_169,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_170,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_171,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_172,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_173,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_174,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_175,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_176,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_177,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_178,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_179,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_180,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_181,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_182,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_183,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_184,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_185,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_186,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_187,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_188,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_189,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_190,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_191,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_192,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_193,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_194,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_195,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_196,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_197,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_198,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_199,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_200,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_201,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_202,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_203,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_204,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_205,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_206,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_207,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_208,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_209,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_210,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_211,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_212,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_213,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_214,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_215,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_216,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_217,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_218,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_219,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_220,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_221,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_222,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_223,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_224,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_225,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_226,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_227,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_228,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_229,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_230,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_231,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_232,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_233,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_234,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_235,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_236,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_237,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_238,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_239,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_240,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_241,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_242,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_243,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_244,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_245,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_246,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_247,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_248,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_249,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_250,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_251,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_252,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_253,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_254,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_255,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_256,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_257,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_258,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_259,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_260,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_261,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_262,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_263,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_264,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_265,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_266,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_267,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_268,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_269,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_270,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_271,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_272,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_273,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_274,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_275,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_276,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_277,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_278,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_279,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_280,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_281,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_282,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_283,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_284,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_285,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_286,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_287,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_288,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_289,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_290,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_291,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_292,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_293,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_294,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_295,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_296,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_297,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_298,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_299,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_300,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_301,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_302,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_303,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_304,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_305,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_306,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_307,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_308,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_309,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_310,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_311,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_312,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_313,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_314,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_315,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_316,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_317,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_318,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_319,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_320,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_321,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_322,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_323,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_324,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_325,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_326,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_327,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_328,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_329,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_330,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_331,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_332,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_333,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_334,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_335,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_336,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_337,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_338,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_339,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_340,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_341,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_342,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_343,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_344,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_345,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_346,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_347,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_348,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_349,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_350,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_351,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_352,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_353,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_354,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_355,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_356,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_357,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_358,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_359,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_360,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_361,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_362,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_363,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_364,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_365,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_366,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_367,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_368,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_369,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_370,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_371,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_372,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_373,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_374,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_375,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_376,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_377,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_378,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_379,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_380,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_381,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_382,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_383,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_384,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_385,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_386,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_387,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_388,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_389,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_390,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_391,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_392,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_393,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_394,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_395,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_396,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_397,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_398,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_399,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_400,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_401,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_402,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_403,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_404,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_405,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_406,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_407,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_408,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_409,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_410,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_411,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_412,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_413,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_414,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_415,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_416,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_417,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_418,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_419,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_420,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_421,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_422,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_423,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_424,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_425,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_426,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_427,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_428,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_429,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_430,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_431,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_432,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_433,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_434,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_435,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_436,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_437,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_438,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_439,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_440,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_441,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_442,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_443,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_444,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_445,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_446,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_447,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_448,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_449,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_450,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_451,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_452,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_453,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_454,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_455,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_456,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_457,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_458,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_459,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_460,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_461,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_462,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_463,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_464,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_465,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_466,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_467,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_468,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_469,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_470,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_471,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_472,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_473,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_474,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_475,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_476,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_477,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_478,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_479,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_480,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_481,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_482,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_483,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_484,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_485,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_486,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_487,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_488,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_489,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_490,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_491,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_492,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_493,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_494,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_495,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_496,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_497,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_498,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_499,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_500,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_501,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_502,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_503,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_504,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_505,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_506,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_507,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_508,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_509,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_510,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_511,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_512,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_513,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_514,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_515,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_516,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_517,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_518,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_519,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_520,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_521,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_522,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_523,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_524,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_525,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_526,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_527,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_528,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_529,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_530,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_531,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_532,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_533,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_534,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_535,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_536,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_537,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_538,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_539,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_540,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_541,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_542,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_543,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_544,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_545,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_546,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_547,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_548,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_549,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_550,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_551,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_552,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_553,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_554,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_555,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_556,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_557,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_558,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_559,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_560,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_561,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_562,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_563,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_564,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_565,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_566,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_567,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_568,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_569,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_570,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_571,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_572,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_573,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_574,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_575,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_576,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_577,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_578,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_579,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_580,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_581,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_582,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_583,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_584,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_585,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_586,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_587,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_588,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_589,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_590,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_591,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_592,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_593,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_594,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_595,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_596,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_597,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_598,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_599,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_600,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_601,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_602,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_603,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_604,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_605,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_606,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_607,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_608,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_609,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_610,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_611,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_612,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_613,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_614,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_615,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_616,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_617,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_618,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_619,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_620,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_621,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_622,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_623,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_624,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_625,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_626,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_627,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_628,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_629,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_630,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_631,x:0.1,y:-121}).wait(1));

	// Layer 1
	this.instance = new lib.Symbol18copy2();
	this.instance.parent = this;
	this.instance.setTransform(-0.2,-0.1,1.037,1,0,0,0,146.7,50.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:150.9,scaleY:1,x:4.1,y:-11.1},0).wait(1).to({scaleY:1.01,y:-22.2},0).wait(1).to({scaleY:1.01,x:4,y:-33.3},0).wait(1).to({scaleY:1.02,y:-44.3},0).wait(1).to({scaleY:1.02,x:3.9,y:-55.4},0).wait(1).to({scaleY:1.02,y:-66.5},0).wait(1).to({scaleY:1.03,x:3.8,y:-77.6},0).wait(1).to({scaleY:1.03,y:-88.6},0).wait(1).to({scaleY:1.03,x:3.7,y:-99.7},0).wait(1).to({scaleY:1.04,y:-110.8},0).wait(1).to({scaleY:1.04,x:3.6,y:-121.9},0).wait(621));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol17copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A2rGaIAAszMAtWAAAIAAMzg");
	mask.setTransform(0.2,-112.3);

	// Layer 3
	this.text = new cjs.Text("Careers", "50px 'Tw Cen MT'", "#000099");
	this.text.textAlign = "center";
	this.text.lineHeight = 56;
	this.text.lineWidth = 295;
	this.text.parent = this;
	this.text.setTransform(1.9,-25.9);

	var maskedShapeInstanceList = [this.text];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({y:-41.4},0).wait(1).to({x:2,y:-56.9},0).wait(1).to({x:2.1,y:-72.4},0).wait(1).to({x:2.2,y:-87.8},0).wait(1).to({x:2.3,y:-103.2},0).wait(1).to({x:2.4,y:-118.5},0).wait(1).to({x:2.5,y:-133.7},0).wait(1).to({x:2.6,y:-145.3},0).wait(624));

	// Layer 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("A3kH8QCIkABEj+QCEnwlAgJMAu5AAAQhvD+g4D9QhvH6EWACg");
	var mask_1_graphics_1 = new cjs.Graphics().p("A3iH8QAxhQAnhRQAcg8AWg8QAnhwAahwQBsm0j0hFQgVgEgZgBMAuZAAAIAXABIgHANQgkBHgdBLQg/CngeCxQhXGvDNBKQATAFAWABg");
	var mask_1_graphics_2 = new cjs.Graphics().p("A3fH8QA1hLAohQQAeg7AUg9QAkhwAWhxQBfmjjqhbQgRgEgUgBMAuTAAAIATABIgHAMQgpBDgdBMQhACjgXC1QhKGdDJBhQAPAEATABg");
	var mask_1_graphics_3 = new cjs.Graphics().p("A3dH8QA6hHAphOQAgg7ASg9QAihvAShyQBRmUjghxQgNgDgPgBMAuPAAAIAOACIgIALQgsA+gfBMQg/CfgQC6Qg+GKDEB4QAMAEAPABg");
	var mask_1_graphics_4 = new cjs.Graphics().p("A3bH8QA/hDAqhMQAhg6ARg9QAehwAPhzQBFmEjYiGQgIgDgLgBMAuLAAAIAKACIgJAKQgwA7ggBLQhACbgIDAQgyF3DACPQAIADALABg");
	var mask_1_graphics_5 = new cjs.Graphics().p("A3ZH8QBDg/AshKQAjg6APg9QAbhwALhzQA4l1jOicQgEgCgGgBMAuGAAAIAFACIgKAKQg0A2ghBLQg/CXgCDFQglFkC8CmQADAEAHAAg");
	var mask_1_graphics_6 = new cjs.Graphics().p("A3XH8QBIg6AthJQAkg5AOg9QAYhwAGh1QAslljFixQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBgBAAMAuDAAAIAAADIgLAJQg4AxghBMQhACSAGDKQgZFSC4C9QgBAAAAABQAAABABAAQAAAAAAABQABAAAAAAg");
	var mask_1_graphics_7 = new cjs.Graphics().p("A3YH8QBMg2AuhHQAmg4ALg+QAWhwADh2QAdlVi6jGIAHgDMAt+AAAIgEADIgMAIQg7AtgjBMQhACOANDQQgNE+C0DUQgFADgDAAg");
	var mask_1_graphics_8 = new cjs.Graphics().p("A3bH8QBQgyAxhFQAng4AKg+QAShwgBh2QARlGixjcIAQgCMAt5AAAIgJAEIgMAHQhAAogjBMQhACLAUDUQAAErCvDsQgJACgIAAg");
	var mask_1_graphics_9 = new cjs.Graphics().p("A3dH8QBVguAxhDQApg3AIg+QAQhxgFh3QAEk2iojxIAZgCMAt0AAAQgGABgHADIgMAGQhEAlglBLQhACHAcDZQAMEZCqECIgZACg");
	var mask_1_graphics_10 = new cjs.Graphics().p("A3fH8QBZgqAyhBQArg3AHg+QAMhwgJh4QgJknidkHIAhgBMAtwAAAQgIABgKADIgNAGQhHAggnBLQhACDAjDfQAZEFClEaIgiABg");
	var mask_1_graphics_11 = new cjs.Graphics().p("A3iH8QBeglA0hAQAsg2AFg/QAJhwgMh5QgWkWiUkdIAqgBMAtrAAAIgWAFIgOAEQhMAcgmBMQhBB+AqDkQAmDzChEwIgsABg");
	var mask_1_graphics_12 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_13 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_14 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_15 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_16 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_17 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_18 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_19 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_20 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_21 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_22 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_23 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_24 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_25 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_26 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_27 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_28 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_29 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_30 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_31 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_32 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_33 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_34 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_35 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_36 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_37 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_38 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_39 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_40 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_41 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_42 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_43 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_44 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_45 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_46 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_47 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_48 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_49 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_50 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_51 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_52 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_53 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_54 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_55 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_56 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_57 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_58 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_59 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_60 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_61 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_62 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_63 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_64 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_65 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_67 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_68 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_70 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_71 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_72 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_73 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_74 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_75 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_76 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_77 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_78 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_79 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_80 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_81 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_82 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_83 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_84 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_85 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_86 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_87 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_88 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_89 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_90 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_91 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_92 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_93 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_94 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_95 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_96 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_97 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_98 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_99 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_100 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_101 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_102 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_103 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_104 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_105 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_106 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_107 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_108 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_109 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_110 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_111 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_112 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_113 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_114 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_115 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_116 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_117 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_118 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_119 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_120 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_121 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_122 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_123 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_124 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_125 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_126 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_127 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_128 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_129 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_130 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_131 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_132 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_133 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_134 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_135 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_136 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_137 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_138 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_139 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_140 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_141 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_142 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_143 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_144 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_145 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_146 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_147 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_148 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_149 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_150 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_151 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_152 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_153 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_154 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_155 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_156 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_157 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_158 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_159 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_160 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_161 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_162 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_163 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_164 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_165 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_166 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_167 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_168 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_169 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_170 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_171 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_172 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_173 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_174 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_175 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_176 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_177 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_178 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_179 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_180 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_181 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_182 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_183 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_184 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_185 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_186 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_187 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_188 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_189 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_190 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_191 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_192 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_193 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_194 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_195 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_196 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_197 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_198 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_199 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_200 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_201 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_202 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_203 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_204 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_205 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_206 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_207 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_208 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_209 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_210 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_211 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_212 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_213 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_214 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_215 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_216 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_217 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_218 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_219 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_220 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_221 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_222 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_223 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_224 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_225 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_226 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_227 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_228 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_229 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_230 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_231 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_232 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_233 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_234 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_235 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_236 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_237 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_238 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_239 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_240 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_241 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_242 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_243 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_244 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_245 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_246 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_247 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_248 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_249 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_250 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_251 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_252 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_253 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_254 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_255 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_256 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_257 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_258 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_259 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_260 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_261 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_262 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_263 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_264 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_265 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_266 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_267 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_268 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_269 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_270 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_271 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_272 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_273 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_274 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_275 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_276 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_277 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_278 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_279 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_280 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_281 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_282 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_283 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_284 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_285 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_286 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_287 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_288 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_289 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_290 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_291 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_292 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_293 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_294 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_295 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_296 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_297 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_298 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_299 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_300 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_301 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_302 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_303 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_304 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_305 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_306 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_307 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_308 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_309 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_310 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_311 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_312 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_313 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_314 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_315 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_316 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_317 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_318 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_319 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_320 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_321 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_322 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_323 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_324 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_325 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_326 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_327 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_328 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_329 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_330 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_331 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_332 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_333 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_334 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_335 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_336 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_337 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_338 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_339 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_340 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_341 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_342 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_343 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_344 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_345 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_346 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_347 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_348 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_349 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_350 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_351 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_352 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_353 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_354 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_355 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_356 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_357 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_358 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_359 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_360 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_361 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_362 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_363 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_364 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_365 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_366 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_367 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_368 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_369 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_370 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_371 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_372 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_373 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_374 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_375 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_376 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_377 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_378 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_379 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_380 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_381 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_382 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_383 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_384 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_385 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_386 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_387 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_388 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_389 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_390 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_391 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_392 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_393 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_394 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_395 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_396 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_397 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_398 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_399 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_400 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_401 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_402 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_403 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_404 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_405 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_406 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_407 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_408 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_409 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_410 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_411 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_412 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_413 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_414 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_415 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_416 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_417 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_418 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_419 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_420 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_421 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_422 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_423 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_424 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_425 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_426 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_427 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_428 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_429 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_430 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_431 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_432 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_433 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_434 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_435 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_436 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_437 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_438 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_439 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_440 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_441 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_442 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_443 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_444 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_445 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_446 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_447 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_448 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_449 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_450 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_451 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_452 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_453 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_454 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_455 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_456 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_457 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_458 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_459 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_460 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_461 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_462 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_463 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_464 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_465 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_466 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_467 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_468 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_469 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_470 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_471 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_472 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_473 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_474 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_475 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_476 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_477 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_478 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_479 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_480 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_481 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_482 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_483 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_484 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_485 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_486 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_487 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_488 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_489 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_490 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_491 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_492 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_493 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_494 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_495 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_496 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_497 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_498 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_499 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_500 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_501 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_502 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_503 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_504 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_505 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_506 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_507 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_508 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_509 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_510 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_511 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_512 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_513 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_514 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_515 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_516 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_517 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_518 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_519 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_520 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_521 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_522 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_523 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_524 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_525 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_526 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_527 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_528 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_529 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_530 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_531 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_532 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_533 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_534 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_535 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_536 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_537 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_538 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_539 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_540 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_541 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_542 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_543 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_544 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_545 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_546 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_547 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_548 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_549 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_550 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_551 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_552 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_553 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_554 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_555 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_556 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_557 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_558 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_559 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_560 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_561 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_562 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_563 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_564 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_565 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_566 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_567 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_568 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_569 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_570 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_571 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_572 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_573 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_574 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_575 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_576 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_577 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_578 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_579 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_580 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_581 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_582 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_583 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_584 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_585 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_586 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_587 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_588 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_589 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_590 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_591 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_592 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_593 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_594 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_595 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_596 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_597 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_598 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_599 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_600 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_601 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_602 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_603 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_604 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_605 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_606 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_607 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_608 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_609 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_610 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_611 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_612 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_613 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_614 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_615 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_616 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_617 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_618 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_619 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_620 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_621 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_622 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_623 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_624 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_625 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_626 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_627 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_628 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_629 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_630 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_1_graphics_631 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_1,x:-0.2,y:-121}).wait(1).to({graphics:mask_1_graphics_2,x:-0.4,y:-121}).wait(1).to({graphics:mask_1_graphics_3,x:-0.6,y:-121}).wait(1).to({graphics:mask_1_graphics_4,x:-0.9,y:-121}).wait(1).to({graphics:mask_1_graphics_5,x:-1.1,y:-121}).wait(1).to({graphics:mask_1_graphics_6,x:-1.2,y:-121}).wait(1).to({graphics:mask_1_graphics_7,x:-1.1,y:-121}).wait(1).to({graphics:mask_1_graphics_8,x:-0.8,y:-121}).wait(1).to({graphics:mask_1_graphics_9,x:-0.6,y:-121}).wait(1).to({graphics:mask_1_graphics_10,x:-0.4,y:-121}).wait(1).to({graphics:mask_1_graphics_11,x:-0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_12,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_13,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_14,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_15,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_16,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_17,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_18,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_19,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_20,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_21,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_22,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_23,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_24,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_25,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_26,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_27,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_28,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_29,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_30,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_31,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_32,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_33,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_34,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_35,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_36,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_37,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_38,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_39,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_40,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_41,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_42,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_43,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_44,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_45,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_46,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_47,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_48,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_49,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_50,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_51,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_52,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_53,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_54,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_55,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_56,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_57,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_58,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_59,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_60,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_61,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_62,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_63,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_64,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_65,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_66,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_67,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_68,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_69,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_70,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_71,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_72,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_73,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_74,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_75,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_76,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_77,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_78,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_79,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_80,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_81,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_82,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_83,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_84,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_85,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_86,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_87,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_88,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_89,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_90,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_91,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_92,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_93,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_94,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_95,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_96,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_97,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_98,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_99,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_100,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_101,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_102,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_103,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_104,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_105,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_106,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_107,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_108,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_109,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_110,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_111,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_112,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_113,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_114,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_115,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_116,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_117,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_118,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_119,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_120,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_121,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_122,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_123,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_124,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_125,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_126,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_127,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_128,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_129,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_130,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_131,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_132,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_133,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_134,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_135,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_136,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_137,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_138,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_139,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_140,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_141,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_142,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_143,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_144,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_145,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_146,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_147,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_148,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_149,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_150,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_151,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_152,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_153,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_154,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_155,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_156,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_157,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_158,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_159,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_160,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_161,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_162,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_163,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_164,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_165,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_166,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_167,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_168,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_169,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_170,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_171,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_172,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_173,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_174,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_175,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_176,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_177,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_178,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_179,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_180,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_181,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_182,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_183,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_184,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_185,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_186,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_187,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_188,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_189,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_190,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_191,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_192,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_193,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_194,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_195,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_196,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_197,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_198,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_199,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_200,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_201,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_202,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_203,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_204,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_205,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_206,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_207,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_208,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_209,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_210,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_211,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_212,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_213,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_214,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_215,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_216,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_217,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_218,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_219,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_220,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_221,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_222,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_223,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_224,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_225,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_226,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_227,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_228,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_229,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_230,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_231,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_232,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_233,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_234,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_235,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_236,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_237,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_238,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_239,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_240,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_241,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_242,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_243,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_244,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_245,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_246,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_247,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_248,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_249,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_250,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_251,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_252,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_253,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_254,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_255,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_256,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_257,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_258,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_259,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_260,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_261,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_262,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_263,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_264,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_265,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_266,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_267,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_268,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_269,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_270,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_271,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_272,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_273,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_274,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_275,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_276,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_277,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_278,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_279,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_280,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_281,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_282,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_283,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_284,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_285,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_286,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_287,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_288,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_289,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_290,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_291,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_292,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_293,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_294,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_295,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_296,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_297,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_298,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_299,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_300,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_301,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_302,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_303,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_304,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_305,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_306,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_307,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_308,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_309,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_310,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_311,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_312,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_313,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_314,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_315,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_316,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_317,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_318,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_319,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_320,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_321,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_322,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_323,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_324,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_325,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_326,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_327,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_328,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_329,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_330,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_331,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_332,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_333,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_334,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_335,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_336,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_337,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_338,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_339,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_340,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_341,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_342,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_343,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_344,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_345,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_346,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_347,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_348,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_349,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_350,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_351,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_352,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_353,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_354,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_355,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_356,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_357,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_358,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_359,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_360,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_361,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_362,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_363,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_364,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_365,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_366,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_367,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_368,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_369,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_370,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_371,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_372,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_373,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_374,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_375,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_376,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_377,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_378,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_379,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_380,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_381,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_382,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_383,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_384,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_385,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_386,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_387,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_388,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_389,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_390,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_391,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_392,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_393,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_394,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_395,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_396,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_397,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_398,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_399,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_400,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_401,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_402,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_403,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_404,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_405,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_406,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_407,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_408,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_409,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_410,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_411,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_412,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_413,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_414,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_415,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_416,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_417,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_418,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_419,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_420,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_421,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_422,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_423,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_424,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_425,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_426,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_427,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_428,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_429,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_430,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_431,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_432,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_433,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_434,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_435,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_436,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_437,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_438,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_439,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_440,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_441,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_442,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_443,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_444,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_445,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_446,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_447,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_448,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_449,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_450,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_451,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_452,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_453,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_454,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_455,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_456,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_457,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_458,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_459,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_460,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_461,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_462,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_463,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_464,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_465,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_466,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_467,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_468,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_469,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_470,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_471,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_472,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_473,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_474,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_475,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_476,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_477,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_478,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_479,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_480,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_481,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_482,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_483,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_484,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_485,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_486,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_487,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_488,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_489,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_490,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_491,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_492,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_493,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_494,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_495,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_496,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_497,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_498,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_499,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_500,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_501,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_502,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_503,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_504,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_505,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_506,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_507,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_508,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_509,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_510,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_511,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_512,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_513,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_514,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_515,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_516,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_517,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_518,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_519,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_520,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_521,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_522,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_523,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_524,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_525,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_526,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_527,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_528,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_529,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_530,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_531,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_532,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_533,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_534,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_535,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_536,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_537,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_538,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_539,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_540,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_541,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_542,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_543,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_544,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_545,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_546,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_547,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_548,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_549,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_550,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_551,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_552,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_553,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_554,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_555,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_556,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_557,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_558,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_559,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_560,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_561,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_562,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_563,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_564,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_565,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_566,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_567,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_568,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_569,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_570,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_571,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_572,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_573,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_574,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_575,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_576,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_577,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_578,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_579,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_580,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_581,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_582,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_583,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_584,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_585,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_586,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_587,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_588,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_589,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_590,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_591,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_592,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_593,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_594,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_595,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_596,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_597,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_598,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_599,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_600,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_601,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_602,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_603,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_604,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_605,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_606,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_607,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_608,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_609,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_610,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_611,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_612,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_613,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_614,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_615,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_616,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_617,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_618,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_619,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_620,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_621,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_622,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_623,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_624,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_625,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_626,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_627,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_628,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_629,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_630,x:0.1,y:-121}).wait(1).to({graphics:mask_1_graphics_631,x:0.1,y:-121}).wait(1));

	// Layer 1
	this.instance = new lib.Symbol18copy();
	this.instance.parent = this;
	this.instance.setTransform(-0.3,-0.1,1.037,1,0,0,0,146.7,50.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:150.9,scaleY:1,x:4.1,y:-11.1},0).wait(1).to({scaleY:1.01,x:4,y:-22.2},0).wait(1).to({scaleY:1.01,y:-33.3},0).wait(1).to({scaleY:1.02,x:3.9,y:-44.3},0).wait(1).to({scaleY:1.02,y:-55.4},0).wait(1).to({scaleY:1.02,x:3.8,y:-66.5},0).wait(1).to({scaleY:1.03,y:-77.6},0).wait(1).to({scaleY:1.03,x:3.7,y:-88.6},0).wait(1).to({scaleY:1.03,y:-99.7},0).wait(1).to({scaleY:1.04,x:3.6,y:-110.8},0).wait(1).to({scaleY:1.04,x:3.5,y:-121.9},0).wait(621));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol17_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("ArAGaIAAszIWBAAIAAMzg");
	mask_2.setTransform(0.2,-112.3);

	// Layer 3
	this.text_1 = new cjs.Text("ESS", "50px 'Tw Cen MT'", "#000099");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 56;
	this.text_1.lineWidth = 136;
	this.text_1.parent = this;
	this.text_1.setTransform(1.3,-25.9);

	var maskedShapeInstanceList = [this.text_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.text_1).wait(1).to({x:1.4,y:-41.4},0).wait(1).to({x:1.5,y:-56.9},0).wait(1).to({x:1.6,y:-72.4},0).wait(1).to({x:1.7,y:-87.8},0).wait(1).to({x:1.8,y:-103.2},0).wait(1).to({x:1.9,y:-118.5},0).wait(1).to({x:2,y:-133.7},0).wait(1).to({x:2.1,y:-145.3},0).wait(624));

	// Layer 2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("A3kH8QCIkABEj+QCEnwlAgJMAu5AAAQhvD+g4D9QhvH6EWACg");
	var mask_3_graphics_1 = new cjs.Graphics().p("A3iH8QAxhQAnhRQAcg8AWg8QAnhwAahwQBsm0j0hFQgVgEgZgBMAuZAAAIAXABIgHANQgkBHgdBLQg/CngeCxQhXGvDNBKQATAFAWABg");
	var mask_3_graphics_2 = new cjs.Graphics().p("A3fH8QA1hLAohQQAeg7AUg9QAkhwAWhxQBfmjjqhbQgRgEgUgBMAuTAAAIATABIgHAMQgpBDgdBMQhACjgXC1QhKGdDJBhQAPAEATABg");
	var mask_3_graphics_3 = new cjs.Graphics().p("A3dH8QA6hHAphOQAgg7ASg9QAihvAShyQBRmUjghxQgNgDgPgBMAuPAAAIAOACIgIALQgsA+gfBMQg/CfgQC6Qg+GKDEB4QAMAEAPABg");
	var mask_3_graphics_4 = new cjs.Graphics().p("A3bH8QA/hDAqhMQAhg6ARg9QAehwAPhzQBFmEjYiGQgIgDgLgBMAuLAAAIAKACIgJAKQgwA7ggBLQhACbgIDAQgyF3DACPQAIADALABg");
	var mask_3_graphics_5 = new cjs.Graphics().p("A3ZH8QBDg/AshKQAjg6APg9QAbhwALhzQA4l1jOicQgEgCgGgBMAuGAAAIAFACIgKAKQg0A2ghBLQg/CXgCDFQglFkC8CmQADAEAHAAg");
	var mask_3_graphics_6 = new cjs.Graphics().p("A3XH8QBIg6AthJQAkg5AOg9QAYhwAGh1QAslljFixQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBgBAAMAuDAAAIAAADIgLAJQg4AxghBMQhACSAGDKQgZFSC4C9QgBAAAAABQAAABABAAQAAAAAAABQABAAAAAAg");
	var mask_3_graphics_7 = new cjs.Graphics().p("A3YH8QBMg2AuhHQAmg4ALg+QAWhwADh2QAdlVi6jGIAHgDMAt+AAAIgEADIgMAIQg7AtgjBMQhACOANDQQgNE+C0DUQgFADgDAAg");
	var mask_3_graphics_8 = new cjs.Graphics().p("A3bH8QBQgyAxhFQAng4AKg+QAShwgBh2QARlGixjcIAQgCMAt5AAAIgJAEIgMAHQhAAogjBMQhACLAUDUQAAErCvDsQgJACgIAAg");
	var mask_3_graphics_9 = new cjs.Graphics().p("A3dH8QBVguAxhDQApg3AIg+QAQhxgFh3QAEk2iojxIAZgCMAt0AAAQgGABgHADIgMAGQhEAlglBLQhACHAcDZQAMEZCqECIgZACg");
	var mask_3_graphics_10 = new cjs.Graphics().p("A3fH8QBZgqAyhBQArg3AHg+QAMhwgJh4QgJknidkHIAhgBMAtwAAAQgIABgKADIgNAGQhHAggnBLQhACDAjDfQAZEFClEaIgiABg");
	var mask_3_graphics_11 = new cjs.Graphics().p("A3iH8QBeglA0hAQAsg2AFg/QAJhwgMh5QgWkWiUkdIAqgBMAtrAAAIgWAFIgOAEQhMAcgmBMQhBB+AqDkQAmDzChEwIgsABg");
	var mask_3_graphics_12 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_13 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_14 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_15 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_16 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_17 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_18 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_19 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_20 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_21 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_22 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_23 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_24 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_25 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_26 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_27 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_28 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_29 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_30 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_31 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_32 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_33 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_34 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_35 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_36 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_37 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_38 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_39 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_40 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_41 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_42 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_43 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_44 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_45 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_46 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_47 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_48 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_49 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_50 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_51 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_52 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_53 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_54 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_55 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_56 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_57 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_58 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_59 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_60 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_61 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_62 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_63 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_64 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_65 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_66 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_67 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_68 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_69 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_70 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_71 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_72 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_73 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_74 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_75 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_76 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_77 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_78 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_79 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_80 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_81 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_82 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_83 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_84 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_85 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_86 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_87 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_88 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_89 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_90 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_91 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_92 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_93 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_94 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_95 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_96 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_97 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_98 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_99 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_100 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_101 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_102 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_103 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_104 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_105 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_106 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_107 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_108 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_109 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_110 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_111 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_112 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_113 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_114 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_115 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_116 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_117 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_118 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_119 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_120 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_121 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_122 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_123 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_124 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_125 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_126 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_127 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_128 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_129 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_130 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_131 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_132 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_133 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_134 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_135 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_136 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_137 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_138 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_139 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_140 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_141 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_142 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_143 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_144 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_145 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_146 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_147 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_148 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_149 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_150 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_151 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_152 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_153 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_154 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_155 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_156 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_157 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_158 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_159 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_160 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_161 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_162 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_163 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_164 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_165 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_166 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_167 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_168 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_169 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_170 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_171 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_172 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_173 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_174 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_175 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_176 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_177 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_178 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_179 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_180 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_181 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_182 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_183 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_184 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_185 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_186 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_187 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_188 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_189 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_190 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_191 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_192 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_193 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_194 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_195 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_196 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_197 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_198 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_199 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_200 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_201 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_202 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_203 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_204 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_205 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_206 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_207 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_208 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_209 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_210 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_211 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_212 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_213 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_214 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_215 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_216 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_217 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_218 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_219 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_220 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_221 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_222 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_223 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_224 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_225 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_226 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_227 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_228 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_229 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_230 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_231 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_232 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_233 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_234 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_235 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_236 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_237 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_238 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_239 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_240 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_241 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_242 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_243 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_244 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_245 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_246 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_247 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_248 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_249 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_250 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_251 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_252 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_253 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_254 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_255 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_256 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_257 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_258 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_259 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_260 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_261 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_262 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_263 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_264 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_265 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_266 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_267 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_268 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_269 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_270 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_271 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_272 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_273 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_274 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_275 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_276 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_277 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_278 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_279 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_280 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_281 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_282 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_283 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_284 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_285 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_286 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_287 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_288 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_289 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_290 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_291 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_292 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_293 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_294 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_295 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_296 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_297 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_298 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_299 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_300 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_301 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_302 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_303 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_304 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_305 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_306 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_307 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_308 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_309 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_310 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_311 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_312 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_313 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_314 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_315 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_316 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_317 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_318 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_319 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_320 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_321 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_322 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_323 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_324 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_325 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_326 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_327 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_328 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_329 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_330 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_331 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_332 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_333 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_334 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_335 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_336 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_337 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_338 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_339 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_340 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_341 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_342 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_343 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_344 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_345 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_346 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_347 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_348 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_349 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_350 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_351 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_352 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_353 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_354 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_355 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_356 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_357 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_358 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_359 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_360 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_361 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_362 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_363 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_364 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_365 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_366 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_367 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_368 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_369 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_370 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_371 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_372 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_373 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_374 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_375 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_376 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_377 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_378 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_379 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_380 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_381 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_382 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_383 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_384 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_385 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_386 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_387 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_388 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_389 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_390 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_391 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_392 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_393 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_394 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_395 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_396 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_397 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_398 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_399 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_400 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_401 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_402 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_403 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_404 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_405 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_406 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_407 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_408 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_409 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_410 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_411 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_412 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_413 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_414 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_415 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_416 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_417 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_418 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_419 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_420 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_421 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_422 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_423 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_424 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_425 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_426 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_427 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_428 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_429 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_430 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_431 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_432 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_433 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_434 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_435 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_436 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_437 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_438 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_439 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_440 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_441 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_442 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_443 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_444 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_445 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_446 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_447 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_448 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_449 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_450 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_451 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_452 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_453 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_454 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_455 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_456 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_457 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_458 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_459 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_460 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_461 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_462 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_463 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_464 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_465 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_466 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_467 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_468 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_469 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_470 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_471 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_472 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_473 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_474 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_475 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_476 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_477 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_478 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_479 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_480 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_481 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_482 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_483 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_484 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_485 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_486 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_487 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_488 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_489 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_490 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_491 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_492 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_493 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_494 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_495 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_496 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_497 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_498 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_499 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_500 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_501 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_502 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_503 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_504 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_505 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_506 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_507 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_508 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_509 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_510 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_511 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_512 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_513 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_514 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_515 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_516 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_517 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_518 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_519 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_520 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_521 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_522 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_523 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_524 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_525 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_526 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_527 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_528 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_529 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_530 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_531 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_532 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_533 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_534 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_535 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_536 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_537 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_538 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_539 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_540 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_541 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_542 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_543 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_544 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_545 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_546 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_547 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_548 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_549 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_550 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_551 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_552 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_553 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_554 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_555 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_556 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_557 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_558 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_559 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_560 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_561 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_562 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_563 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_564 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_565 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_566 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_567 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_568 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_569 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_570 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_571 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_572 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_573 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_574 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_575 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_576 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_577 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_578 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_579 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_580 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_581 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_582 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_583 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_584 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_585 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_586 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_587 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_588 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_589 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_590 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_591 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_592 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_593 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_594 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_595 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_596 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_597 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_598 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_599 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_600 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_601 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_602 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_603 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_604 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_605 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_606 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_607 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_608 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_609 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_610 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_611 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_612 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_613 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_614 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_615 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_616 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_617 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_618 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_619 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_620 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_621 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_622 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_623 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_624 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_625 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_626 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_627 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_628 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_629 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_630 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");
	var mask_3_graphics_631 = new cjs.Graphics().p("A3kH8QBighA2g+QAtg2AEg+QATlkjMnAMAubAAAQgUACgWAHQhPAXgoBMQiADwE/Kbg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_1,x:-0.2,y:-121}).wait(1).to({graphics:mask_3_graphics_2,x:-0.4,y:-121}).wait(1).to({graphics:mask_3_graphics_3,x:-0.6,y:-121}).wait(1).to({graphics:mask_3_graphics_4,x:-0.9,y:-121}).wait(1).to({graphics:mask_3_graphics_5,x:-1.1,y:-121}).wait(1).to({graphics:mask_3_graphics_6,x:-1.2,y:-121}).wait(1).to({graphics:mask_3_graphics_7,x:-1.1,y:-121}).wait(1).to({graphics:mask_3_graphics_8,x:-0.8,y:-121}).wait(1).to({graphics:mask_3_graphics_9,x:-0.6,y:-121}).wait(1).to({graphics:mask_3_graphics_10,x:-0.4,y:-121}).wait(1).to({graphics:mask_3_graphics_11,x:-0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_12,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_13,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_14,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_15,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_16,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_17,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_18,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_19,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_20,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_21,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_22,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_23,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_24,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_25,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_26,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_27,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_28,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_29,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_30,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_31,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_32,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_33,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_34,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_35,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_36,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_37,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_38,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_39,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_40,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_41,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_42,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_43,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_44,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_45,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_46,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_47,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_48,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_49,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_50,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_51,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_52,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_53,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_54,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_55,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_56,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_57,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_58,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_59,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_60,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_61,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_62,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_63,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_64,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_65,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_66,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_67,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_68,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_69,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_70,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_71,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_72,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_73,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_74,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_75,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_76,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_77,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_78,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_79,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_80,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_81,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_82,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_83,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_84,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_85,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_86,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_87,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_88,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_89,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_90,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_91,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_92,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_93,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_94,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_95,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_96,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_97,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_98,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_99,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_100,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_101,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_102,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_103,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_104,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_105,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_106,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_107,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_108,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_109,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_110,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_111,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_112,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_113,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_114,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_115,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_116,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_117,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_118,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_119,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_120,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_121,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_122,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_123,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_124,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_125,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_126,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_127,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_128,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_129,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_130,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_131,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_132,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_133,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_134,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_135,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_136,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_137,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_138,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_139,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_140,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_141,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_142,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_143,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_144,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_145,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_146,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_147,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_148,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_149,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_150,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_151,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_152,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_153,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_154,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_155,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_156,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_157,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_158,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_159,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_160,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_161,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_162,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_163,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_164,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_165,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_166,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_167,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_168,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_169,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_170,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_171,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_172,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_173,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_174,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_175,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_176,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_177,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_178,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_179,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_180,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_181,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_182,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_183,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_184,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_185,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_186,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_187,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_188,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_189,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_190,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_191,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_192,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_193,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_194,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_195,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_196,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_197,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_198,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_199,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_200,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_201,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_202,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_203,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_204,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_205,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_206,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_207,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_208,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_209,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_210,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_211,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_212,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_213,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_214,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_215,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_216,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_217,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_218,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_219,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_220,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_221,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_222,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_223,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_224,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_225,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_226,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_227,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_228,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_229,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_230,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_231,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_232,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_233,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_234,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_235,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_236,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_237,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_238,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_239,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_240,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_241,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_242,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_243,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_244,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_245,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_246,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_247,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_248,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_249,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_250,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_251,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_252,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_253,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_254,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_255,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_256,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_257,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_258,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_259,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_260,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_261,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_262,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_263,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_264,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_265,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_266,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_267,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_268,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_269,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_270,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_271,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_272,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_273,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_274,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_275,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_276,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_277,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_278,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_279,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_280,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_281,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_282,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_283,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_284,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_285,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_286,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_287,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_288,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_289,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_290,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_291,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_292,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_293,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_294,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_295,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_296,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_297,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_298,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_299,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_300,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_301,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_302,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_303,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_304,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_305,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_306,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_307,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_308,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_309,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_310,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_311,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_312,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_313,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_314,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_315,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_316,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_317,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_318,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_319,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_320,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_321,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_322,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_323,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_324,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_325,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_326,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_327,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_328,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_329,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_330,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_331,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_332,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_333,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_334,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_335,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_336,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_337,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_338,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_339,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_340,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_341,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_342,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_343,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_344,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_345,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_346,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_347,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_348,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_349,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_350,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_351,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_352,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_353,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_354,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_355,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_356,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_357,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_358,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_359,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_360,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_361,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_362,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_363,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_364,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_365,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_366,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_367,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_368,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_369,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_370,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_371,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_372,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_373,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_374,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_375,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_376,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_377,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_378,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_379,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_380,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_381,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_382,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_383,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_384,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_385,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_386,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_387,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_388,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_389,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_390,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_391,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_392,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_393,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_394,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_395,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_396,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_397,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_398,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_399,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_400,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_401,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_402,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_403,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_404,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_405,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_406,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_407,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_408,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_409,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_410,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_411,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_412,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_413,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_414,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_415,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_416,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_417,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_418,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_419,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_420,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_421,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_422,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_423,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_424,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_425,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_426,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_427,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_428,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_429,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_430,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_431,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_432,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_433,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_434,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_435,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_436,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_437,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_438,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_439,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_440,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_441,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_442,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_443,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_444,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_445,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_446,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_447,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_448,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_449,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_450,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_451,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_452,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_453,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_454,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_455,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_456,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_457,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_458,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_459,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_460,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_461,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_462,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_463,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_464,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_465,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_466,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_467,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_468,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_469,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_470,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_471,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_472,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_473,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_474,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_475,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_476,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_477,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_478,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_479,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_480,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_481,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_482,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_483,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_484,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_485,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_486,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_487,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_488,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_489,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_490,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_491,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_492,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_493,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_494,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_495,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_496,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_497,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_498,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_499,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_500,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_501,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_502,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_503,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_504,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_505,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_506,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_507,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_508,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_509,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_510,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_511,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_512,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_513,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_514,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_515,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_516,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_517,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_518,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_519,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_520,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_521,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_522,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_523,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_524,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_525,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_526,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_527,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_528,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_529,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_530,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_531,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_532,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_533,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_534,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_535,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_536,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_537,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_538,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_539,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_540,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_541,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_542,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_543,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_544,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_545,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_546,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_547,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_548,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_549,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_550,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_551,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_552,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_553,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_554,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_555,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_556,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_557,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_558,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_559,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_560,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_561,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_562,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_563,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_564,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_565,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_566,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_567,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_568,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_569,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_570,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_571,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_572,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_573,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_574,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_575,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_576,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_577,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_578,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_579,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_580,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_581,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_582,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_583,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_584,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_585,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_586,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_587,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_588,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_589,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_590,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_591,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_592,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_593,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_594,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_595,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_596,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_597,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_598,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_599,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_600,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_601,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_602,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_603,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_604,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_605,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_606,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_607,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_608,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_609,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_610,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_611,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_612,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_613,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_614,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_615,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_616,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_617,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_618,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_619,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_620,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_621,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_622,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_623,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_624,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_625,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_626,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_627,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_628,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_629,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_630,x:0.1,y:-121}).wait(1).to({graphics:mask_3_graphics_631,x:0.1,y:-121}).wait(1));

	// Layer 1
	this.instance_1 = new lib.Symbol18_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.3,-0.1,1.037,1,0,0,0,146.7,50.3);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:150.9,scaleY:1,x:4.1,y:-11.1},0).wait(1).to({scaleY:1.01,x:4,y:-22.2},0).wait(1).to({scaleY:1.01,y:-33.3},0).wait(1).to({scaleY:1.02,x:3.9,y:-44.3},0).wait(1).to({scaleY:1.02,y:-55.4},0).wait(1).to({scaleY:1.02,x:3.8,y:-66.5},0).wait(1).to({scaleY:1.03,y:-77.6},0).wait(1).to({scaleY:1.03,x:3.7,y:-88.6},0).wait(1).to({scaleY:1.03,y:-99.7},0).wait(1).to({scaleY:1.04,x:3.6,y:-110.8},0).wait(1).to({scaleY:1.04,x:3.5,y:-121.9},0).wait(621));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol13copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol14copy3();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1,0,0,0,5.9,174);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:-32.4},0).wait(1).to({y:-64.9},0).wait(1).to({y:-97.4},0).wait(1).to({y:-129.8},0).wait(1).to({y:-162.3},0).wait(1).to({y:-194.8},0).wait(1).to({y:-227.3},0).wait(1).to({y:-259.7},0).wait(1).to({y:-292.2},0).wait(1).to({x:-0.1,y:-324.7},0).wait(1).to({y:-357.1},0).wait(1).to({y:-389.6},0).wait(1).to({y:-422.1},0).wait(1).to({y:-454.6},0).wait(1).to({y:-487},0).wait(1).to({y:-519.5},0).wait(1).to({y:-552},0).wait(1).to({y:-584.4},0).wait(1).to({x:-0.2,y:-616.9},0).wait(1).to({y:-649.4},0).wait(1).to({y:-681.9},0).wait(1).to({y:-714.3},0).wait(1).to({y:-746.8},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.9,-174,11.8,348);


(lib.Symbol13copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol14copy2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1,0,0,0,5.9,174);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:-32.4},0).wait(1).to({y:-64.9},0).wait(1).to({y:-97.4},0).wait(1).to({y:-129.8},0).wait(1).to({y:-162.3},0).wait(1).to({y:-194.8},0).wait(1).to({y:-227.3},0).wait(1).to({y:-259.7},0).wait(1).to({y:-292.2},0).wait(1).to({x:-0.1,y:-324.7},0).wait(1).to({y:-357.1},0).wait(1).to({y:-389.6},0).wait(1).to({y:-422.1},0).wait(1).to({y:-454.6},0).wait(1).to({y:-487},0).wait(1).to({y:-519.5},0).wait(1).to({y:-552},0).wait(1).to({y:-584.4},0).wait(1).to({x:-0.2,y:-616.9},0).wait(1).to({y:-649.4},0).wait(1).to({y:-681.9},0).wait(1).to({y:-714.3},0).wait(1).to({y:-746.8},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.9,-174,11.8,348);


(lib.Symbol13copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol14copy();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1,0,0,0,5.9,174);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:-32.4},0).wait(1).to({y:-64.9},0).wait(1).to({y:-97.4},0).wait(1).to({y:-129.8},0).wait(1).to({y:-162.3},0).wait(1).to({y:-194.8},0).wait(1).to({y:-227.3},0).wait(1).to({y:-259.7},0).wait(1).to({y:-292.2},0).wait(1).to({x:-0.1,y:-324.7},0).wait(1).to({y:-357.1},0).wait(1).to({y:-389.6},0).wait(1).to({y:-422.1},0).wait(1).to({y:-454.6},0).wait(1).to({y:-487},0).wait(1).to({y:-519.5},0).wait(1).to({y:-552},0).wait(1).to({y:-584.4},0).wait(1).to({x:-0.2,y:-616.9},0).wait(1).to({y:-649.4},0).wait(1).to({y:-681.9},0).wait(1).to({y:-714.3},0).wait(1).to({y:-746.8},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.9,-174,11.8,348);


(lib.Symbol13_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance_1 = new lib.Symbol14_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1,1,0,0,0,5.9,174);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({y:-32.4},0).wait(1).to({y:-64.9},0).wait(1).to({y:-97.4},0).wait(1).to({y:-129.8},0).wait(1).to({y:-162.3},0).wait(1).to({y:-194.8},0).wait(1).to({y:-227.3},0).wait(1).to({y:-259.7},0).wait(1).to({y:-292.2},0).wait(1).to({x:-0.1,y:-324.7},0).wait(1).to({y:-357.1},0).wait(1).to({y:-389.6},0).wait(1).to({y:-422.1},0).wait(1).to({y:-454.6},0).wait(1).to({y:-487},0).wait(1).to({y:-519.5},0).wait(1).to({y:-552},0).wait(1).to({y:-584.4},0).wait(1).to({x:-0.2,y:-616.9},0).wait(1).to({y:-649.4},0).wait(1).to({y:-681.9},0).wait(1).to({y:-714.3},0).wait(1).to({y:-746.8},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.9,-174,11.8,348);


(lib.Symbol11copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol12copy3();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1,0,0,0,174,5.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:-42,y:0.2},0).wait(1).to({x:-84,y:0.4},0).wait(1).to({x:-126,y:0.5},0).wait(1).to({x:-168.1,y:0.7},0).wait(1).to({x:-210.1,y:0.8},0).wait(1).to({x:-252.1,y:1},0).wait(1).to({x:-294.2,y:1.1},0).wait(1).to({x:-336.2,y:1.3},0).wait(1).to({x:-378.2,y:1.4},0).wait(1).to({x:-420.3,y:1.6},0).wait(1).to({x:-462.4,y:1.7},0).wait(1).to({x:-504.4,y:1.9},0).wait(1).to({x:-546.4,y:2},0).wait(1).to({x:-588.4,y:2.2},0).wait(1).to({x:-630.5,y:2.3},0).wait(1).to({x:-672.5,y:2.5},0).wait(1).to({x:-714.6,y:2.6},0).wait(1).to({x:-756.6,y:2.8},0).wait(1).to({x:-798.7,y:2.9},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-174,-5.9,348,11.8);


(lib.Symbol11copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol12copy2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1,0,0,0,174,5.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:-42,y:0.2},0).wait(1).to({x:-84,y:0.4},0).wait(1).to({x:-126,y:0.5},0).wait(1).to({x:-168.1,y:0.7},0).wait(1).to({x:-210.1,y:0.8},0).wait(1).to({x:-252.1,y:1},0).wait(1).to({x:-294.2,y:1.1},0).wait(1).to({x:-336.2,y:1.3},0).wait(1).to({x:-378.2,y:1.4},0).wait(1).to({x:-420.3,y:1.6},0).wait(1).to({x:-462.4,y:1.7},0).wait(1).to({x:-504.4,y:1.9},0).wait(1).to({x:-546.4,y:2},0).wait(1).to({x:-588.4,y:2.2},0).wait(1).to({x:-630.5,y:2.3},0).wait(1).to({x:-672.5,y:2.5},0).wait(1).to({x:-714.6,y:2.6},0).wait(1).to({x:-756.6,y:2.8},0).wait(1).to({x:-798.7,y:2.9},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-174,-5.9,348,11.8);


(lib.Symbol11copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol12copy();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1,0,0,0,174,5.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:-42,y:0.2},0).wait(1).to({x:-84,y:0.4},0).wait(1).to({x:-126,y:0.5},0).wait(1).to({x:-168.1,y:0.7},0).wait(1).to({x:-210.1,y:0.8},0).wait(1).to({x:-252.1,y:1},0).wait(1).to({x:-294.2,y:1.1},0).wait(1).to({x:-336.2,y:1.3},0).wait(1).to({x:-378.2,y:1.4},0).wait(1).to({x:-420.3,y:1.6},0).wait(1).to({x:-462.4,y:1.7},0).wait(1).to({x:-504.4,y:1.9},0).wait(1).to({x:-546.4,y:2},0).wait(1).to({x:-588.4,y:2.2},0).wait(1).to({x:-630.5,y:2.3},0).wait(1).to({x:-672.5,y:2.5},0).wait(1).to({x:-714.6,y:2.6},0).wait(1).to({x:-756.6,y:2.8},0).wait(1).to({x:-798.7,y:2.9},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-174,-5.9,348,11.8);


(lib.Symbol11_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance_1 = new lib.Symbol12_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1,1,0,0,0,174,5.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({x:-42,y:0.2},0).wait(1).to({x:-84,y:0.4},0).wait(1).to({x:-126,y:0.5},0).wait(1).to({x:-168.1,y:0.7},0).wait(1).to({x:-210.1,y:0.8},0).wait(1).to({x:-252.1,y:1},0).wait(1).to({x:-294.2,y:1.1},0).wait(1).to({x:-336.2,y:1.3},0).wait(1).to({x:-378.2,y:1.4},0).wait(1).to({x:-420.3,y:1.6},0).wait(1).to({x:-462.4,y:1.7},0).wait(1).to({x:-504.4,y:1.9},0).wait(1).to({x:-546.4,y:2},0).wait(1).to({x:-588.4,y:2.2},0).wait(1).to({x:-630.5,y:2.3},0).wait(1).to({x:-672.5,y:2.5},0).wait(1).to({x:-714.6,y:2.6},0).wait(1).to({x:-756.6,y:2.8},0).wait(1).to({x:-798.7,y:2.9},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-174,-5.9,348,11.8);


(lib.Symbol9copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol10copy3();
	this.instance.parent = this;
	this.instance.setTransform(0,-0.1,1,1,0,0,0,172.8,6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:6.1,x:43,y:0},0).wait(1).to({x:86},0).wait(1).to({x:129},0).wait(1).to({x:172},0).wait(1).to({x:214.9},0).wait(1).to({x:257.9},0).wait(1).to({x:300.8},0).wait(1).to({x:343.9},0).wait(1).to({x:386.8},0).wait(1).to({x:429.8},0).wait(1).to({x:472.8},0).wait(1).to({x:515.8},0).wait(1).to({x:558.8},0).wait(1).to({x:601.7},0).wait(1).to({x:644.8},0).wait(1).to({x:687.7},0).wait(1).to({x:730.7},0).wait(1).to({x:773.7},0).wait(1).to({x:816.7},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-172.8,-6.1,345.6,12.1);


(lib.Symbol9copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol10copy2();
	this.instance.parent = this;
	this.instance.setTransform(0,-0.1,1,1,0,0,0,172.8,6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:6.1,x:43,y:0},0).wait(1).to({x:86},0).wait(1).to({x:129},0).wait(1).to({x:172},0).wait(1).to({x:214.9},0).wait(1).to({x:257.9},0).wait(1).to({x:300.8},0).wait(1).to({x:343.9},0).wait(1).to({x:386.8},0).wait(1).to({x:429.8},0).wait(1).to({x:472.8},0).wait(1).to({x:515.8},0).wait(1).to({x:558.8},0).wait(1).to({x:601.7},0).wait(1).to({x:644.8},0).wait(1).to({x:687.7},0).wait(1).to({x:730.7},0).wait(1).to({x:773.7},0).wait(1).to({x:816.7},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-172.8,-6.1,345.6,12.1);


(lib.Symbol9copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol10copy();
	this.instance.parent = this;
	this.instance.setTransform(0,-0.1,1,1,0,0,0,172.8,6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:6.1,x:43,y:0},0).wait(1).to({x:86},0).wait(1).to({x:129},0).wait(1).to({x:172},0).wait(1).to({x:214.9},0).wait(1).to({x:257.9},0).wait(1).to({x:300.8},0).wait(1).to({x:343.9},0).wait(1).to({x:386.8},0).wait(1).to({x:429.8},0).wait(1).to({x:472.8},0).wait(1).to({x:515.8},0).wait(1).to({x:558.8},0).wait(1).to({x:601.7},0).wait(1).to({x:644.8},0).wait(1).to({x:687.7},0).wait(1).to({x:730.7},0).wait(1).to({x:773.7},0).wait(1).to({x:816.7},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-172.8,-6.1,345.6,12.1);


(lib.Symbol9_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance_1 = new lib.Symbol10_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-0.1,1,1,0,0,0,172.8,6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY:6.1,x:43,y:0},0).wait(1).to({x:86},0).wait(1).to({x:129},0).wait(1).to({x:172},0).wait(1).to({x:214.9},0).wait(1).to({x:257.9},0).wait(1).to({x:300.8},0).wait(1).to({x:343.9},0).wait(1).to({x:386.8},0).wait(1).to({x:429.8},0).wait(1).to({x:472.8},0).wait(1).to({x:515.8},0).wait(1).to({x:558.8},0).wait(1).to({x:601.7},0).wait(1).to({x:644.8},0).wait(1).to({x:687.7},0).wait(1).to({x:730.7},0).wait(1).to({x:773.7},0).wait(1).to({x:816.7},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-172.8,-6.1,345.6,12.1);


(lib.Symbol6copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 6
	this.instance = new lib.Symbol26copy3();
	this.instance.parent = this;
	this.instance.setTransform(0,0.1,1,1,0,0,0,151,50.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhrCXIAAknIAqAAIAAAoQAfguAvAAQAmAAAdAfQAcAfAAAsQAAArgdAfQgcAggnAAQgVAAgVgMQgVgMgNgWIAACHgAgyhbQgUAUAAAbQAAAbATAUQAUAUAbAAQAbAAAUgUQAUgTAAgcQAAgbgUgUQgUgUgaAAQgbAAgUAUg");
	this.shape.setTransform(90.6,8.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhPBLQgcgfAAgsQAAgqAdggQAcgfAmAAQAXAAAVANQAWANALAUIAAgpIArAAIAADJIgrAAIAAgoQgfAtgtAAQgnAAgdgfgAgqguQgUAUAAAaQAAAcATAUQAUAUAbAAQAcAAATgUQAUgUAAgbQAAgbgUgTQgTgUgcAAQgaAAgUATg");
	this.shape_1.setTransform(62.1,3.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhYgqIg0DGIgpAAIBVlDIBgDnIBhjnIBVFDIgqAAIgzjFIhZDRg");
	this.shape_2.setTransform(29.5,-1.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhFBDIAigQQARARASAAQANAAAKgHQAKgIAAgJQAAgRghgNQgjgOgNgNQgOgNAAgVQAAgZATgRQATgQAcAAQAcAAAkAdIgdAZQgLgIgIgEQgIgEgLAAQgZAAAAATQAAAOAgANQAhANAOAOQAPAPAAAWQAAAagVATQgVASgcAAQgpAAgcgng");
	this.shape_3.setTransform(-12,3.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgUCeIAAk8IApAAIAAE8g");
	this.shape_4.setTransform(-25.6,-1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgUCeIAAk8IApAAIAAE8g");
	this.shape_5.setTransform(-36.6,-1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgUCWIAAjIIApAAIAADIgAgWhdQgKgKAAgOQAAgNAKgJQAKgKAMAAQANAAAKAKQAKAJAAANQAAAOgKAKQgKAJgNAAQgMAAgKgJg");
	this.shape_6.setTransform(-47.7,-1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAmCeIhVhqIAABqIgrAAIAAk8IArAAIAADMIBShYIA3AAIhXBcIBYBsg");
	this.shape_7.setTransform(-63.3,-1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag7CRQgegWgQgrIArgMQAXA1AvAAQAXAAAPgOQAQgOAAgVQAAgNgIgNQgIgMgMgJQgMgIgZgLQgagJgPgJQgOgJgKgMQgKgNgFgMQgFgMAAgOQAAghAbgYQAbgYAlAAQAaAAAaALQAaALARAXIgiAbQgOgOgLgHQgLgHgVAAQgWAAgOALQgOAKAAARQAAANAMALQAMALAeANQAdANARALQARALAKAMQALAOAGAPQAFAPAAAQQAAAngcAbQgdAcgoAAQgmAAgegVg");
	this.shape_8.setTransform(-87.5,-1.6);

	this.instance_1 = new lib.Symbol19copy3("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2.7,-3.2);

	this.instance_2 = new lib.Symbol24copy3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-1,-1.7);

	this.instance_3 = new lib.Symbol17copy3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-1.1,120.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A8WLGIAA2LMA4tAAAIAAWLg");
	mask.setTransform(-0.9,-0.2);

	// Layer 1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000099").s().p("A3lH6IAAvzMAvLAAAIAAPzg");

	this.instance_4 = new lib.Symbol13copy3();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-176.4,381.6);

	this.instance_5 = new lib.Symbol11copy3();
	this.instance_5.parent = this;
	this.instance_5.setTransform(399.7,64.9,1,1,-0.1,0,0,0.1,0.1);

	this.instance_6 = new lib.Symbol9copy3();
	this.instance_6.parent = this;
	this.instance_6.setTransform(174.5,-295.2,1,1,90);

	this.instance_7 = new lib.Symbol9copy3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-399.1,-65.5);

	var maskedShapeInstanceList = [this.shape_9,this.instance_4,this.instance_5,this.instance_6,this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9}]}).to({state:[{t:this.shape_9},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-151,-50.5,302.1,101.1);


(lib.Symbol6copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 6
	this.instance = new lib.Symbol26copy2();
	this.instance.parent = this;
	this.instance.setTransform(0,0.1,1,1,0,0,0,151,50.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAtBnIAAiDQAAgRgLgKQgLgMgQAAQgUAAgPASQgQATAAAZIAABsIgqAAIAAjIIAqAAIAAAiQASgVAOgJQAPgKASAAQAbAAAUASQATATAAAZIAACQg");
	this.shape.setTransform(99.3,3.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhKBKQghggAAgqQAAgpAhggQAgggAqAAQArAAAhAfQAgAgAAAqQAAAqggAgQggAggpAAQgsAAghgggAgugsQgTATgBAaQAAAZAVATQAUATAaAAQAbAAATgTQAUgUAAgZQAAgZgTgTQgUgTgbAAQgaAAgVATg");
	this.shape_1.setTransform(76.1,3.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgUCWIAAjIIApAAIAADIgAgWhdQgKgKAAgOQAAgNAKgJQAKgKAMAAQANAAAKAKQAKAJAAANQAAAOgKAKQgKAJgNAAQgMAAgKgJg");
	this.shape_2.setTransform(57.9,-1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgYCCIAAihIgiAAIAAgoIAiAAIAAg6IApAAIAAA7IAqAAIAAAnIgqAAIAAChg");
	this.shape_3.setTransform(45.8,0.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhPBLQgcgfAAgsQAAgqAdggQAcgfAmAAQAXAAAVANQAWANALAUIAAgpIArAAIAADJIgrAAIAAgoQgfAtgtAAQgnAAgdgfgAgqguQgUAUAAAaQAAAcATAUQAUAUAbAAQAcAAATgUQAUgUAAgbQAAgbgUgTQgTgUgcAAQgaAAgUATg");
	this.shape_4.setTransform(24.7,3.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhPCCQgcggAAgsQAAgrAcgeQAdgfAoAAQAXAAAUANQAVANAMAVIAAidIAqAAIAAE8IgpAAIAAgqQgfAvgvAAQgoAAgcgfgAgsAHQgTAUAAAcQAAAbAUAUQAUAUAaAAQAcAAAUgUQAUgTgBgcQABgbgUgUQgUgTgbAAQgcAAgUASg");
	this.shape_5.setTransform(-3,-1.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAsBnIAAiDQAAgRgKgKQgKgMgRAAQgUAAgPASQgQATAAAZIAABsIgqAAIAAjIIApAAIAAAiQATgVAPgJQAOgKASAAQAcAAATASQATATAAAZIAACQg");
	this.shape_6.setTransform(-27.3,3.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag+BPQgZgYAAgnIAAh2IArAAIAABwQAAA1AtgBQAUAAANgOQAMgOgBgYIAAhwIArAAIAAB3QAAAmgZAYQgZAZgmAAQgmAAgYgZg");
	this.shape_7.setTransform(-49.1,4.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhKBKQghggAAgqQAAgpAhggQAgggAqAAQArAAAhAfQAgAgAAAqQAAAqggAgQggAggpAAQgsAAghgggAgugsQgTATgBAaQAAAZAVATQAUATAaAAQAbAAATgTQAUgUAAgZQAAgZgTgTQgUgTgbAAQgaAAgVATg");
	this.shape_8.setTransform(-72.4,3.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhVCbIAAk1ICrAAIAAAqIiBAAIAABNICBAAIAAAqIiBAAIAACUg");
	this.shape_9.setTransform(-94.8,-1.6);

	this.instance_1 = new lib.Symbol19copy2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2.7,-3.2);

	this.instance_2 = new lib.Symbol24copy2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-1,-1.7);

	this.instance_3 = new lib.Symbol17copy2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-1.1,120.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A8WLGIAA2LMA4tAAAIAAWLg");
	mask.setTransform(-0.9,-0.2);

	// Layer 1
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000099").s().p("A3lH6IAAvzMAvLAAAIAAPzg");

	this.instance_4 = new lib.Symbol13copy2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-176.4,381.6);

	this.instance_5 = new lib.Symbol11copy2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(399.7,64.9,1,1,-0.1,0,0,0.1,0.1);

	this.instance_6 = new lib.Symbol9copy2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(174.5,-295.2,1,1,90);

	this.instance_7 = new lib.Symbol9copy2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-399.1,-65.5);

	var maskedShapeInstanceList = [this.shape_10,this.instance_4,this.instance_5,this.instance_6,this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10}]}).to({state:[{t:this.shape_10},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-151,-50.5,302.1,101.1);


(lib.Symbol6copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 6
	this.instance = new lib.Symbol26copy();
	this.instance.parent = this;
	this.instance.setTransform(0,0.1,1,1,0,0,0,151,50.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhFBDIAigQQARARASAAQANAAAKgHQAKgIAAgJQAAgRghgNQgjgOgNgNQgOgNAAgVQAAgZATgRQATgQAcAAQAcAAAkAdIgdAZQgLgIgIgEQgIgEgLAAQgZAAAAATQAAAOAgANQAhANAOAOQAPAPAAAWQAAAagVATQgVASgcAAQgpAAgcgng");
	this.shape.setTransform(72.5,3.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag8BnIAAjIIApAAIAAAqQAPgaAMgKQAOgMAVAAQAHABALADIgNAqIgQgDQgWABgNAPQgPAOAAAXIAABug");
	this.shape_1.setTransform(57.1,3.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhKBMQgegfAAgtQAAgrAfgfQAegfArAAQAsAAAfAgQAfAfgBAyIirAAQAGAfAUAPQAUAOAWAAQAkAAAZgeIAfAXQgjAtg7AAQgsAAgegegAg9gZIB6AAQgVgpgoAAQgqAAgTApg");
	this.shape_2.setTransform(35,3.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhKBMQgegfAAgtQAAgrAfgfQAegfArAAQAsAAAfAgQAfAfgBAyIirAAQAGAfAUAPQAUAOAWAAQAkAAAZgeIAfAXQgjAtg7AAQgsAAgegegAg9gZIB6AAQgVgpgoAAQgqAAgTApg");
	this.shape_3.setTransform(10,3.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag8BnIAAjIIApAAIAAAqQAPgaAMgKQAOgMAVAAQAHABALADIgNAqIgQgDQgWABgNAPQgPAOAAAXIAABug");
	this.shape_4.setTransform(-9.5,3.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhPBLQgcgfAAgsQAAgqAdggQAcgfAmAAQAXAAAVANQAWANALAUIAAgpIArAAIAADJIgrAAIAAgoQgfAtgtAAQgnAAgdgfgAgqguQgUAUAAAaQAAAcATAUQAUAUAbAAQAcAAATgUQAUgUAAgbQAAgbgUgTQgTgUgcAAQgaAAgUATg");
	this.shape_5.setTransform(-33.4,3.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhRB1QgzgxAAhEQAAhEAygwQAzgxBGAAQAtAAAxAVIAAAwQgygZgqAAQg2AAglAjQglAjAAAzQAAAzAmAjQAmAjA4AAQAqAAAugaIAAAwQgqAXgxAAQhIAAgzgxg");
	this.shape_6.setTransform(-61.8,-1.6);

	this.instance_1 = new lib.Symbol19copy("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2.7,-3.2);

	this.instance_2 = new lib.Symbol24copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-1,-1.7);

	this.instance_3 = new lib.Symbol17copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-1.1,120.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A8WLGIAA2LMA4tAAAIAAWLg");
	mask.setTransform(-0.9,-0.2);

	// Layer 1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000099").s().p("A3lH6IAAvzMAvLAAAIAAPzg");

	this.instance_4 = new lib.Symbol13copy();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-176.4,381.6);

	this.instance_5 = new lib.Symbol11copy();
	this.instance_5.parent = this;
	this.instance_5.setTransform(399.7,64.9,1,1,-0.1,0,0,0.1,0.1);

	this.instance_6 = new lib.Symbol9copy();
	this.instance_6.parent = this;
	this.instance_6.setTransform(174.5,-295.2,1,1,90);

	this.instance_7 = new lib.Symbol9copy();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-399.1,-65.5);

	var maskedShapeInstanceList = [this.shape_7,this.instance_4,this.instance_5,this.instance_6,this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7}]}).to({state:[{t:this.shape_7},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-151,-50.5,302.1,101.1);


(lib.Symbol6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 6
	this.instance_8 = new lib.Symbol26_1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(0,0.1,1,1,0,0,0,151,50.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag7CRQgegWgQgrIArgMQAXA1AvAAQAXAAAPgOQAQgOAAgVQAAgNgIgNQgIgMgMgJQgMgIgZgLQgagJgPgJQgOgJgKgMQgKgNgFgMQgFgMAAgOQAAghAbgYQAbgYAlAAQAaAAAaALQAaALARAXIgiAbQgOgOgLgHQgLgHgVAAQgWAAgOALQgOAKAAARQAAANAMALQAMALAeANQAdANARALQARALAKAMQALAOAGAPQAFAPAAAQQAAAngcAbQgdAcgoAAQgmAAgegVg");
	this.shape_10.setTransform(22.3,-1.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag7CRQgegWgQgrIArgMQAXA1AvAAQAXAAAPgOQAQgOAAgVQAAgNgIgNQgIgMgMgJQgMgIgZgLQgagJgPgJQgOgJgKgMQgKgNgFgMQgFgMAAgOQAAghAbgYQAbgYAlAAQAaAAAaALQAaALARAXIgiAbQgOgOgLgHQgLgHgVAAQgWAAgOALQgOAKAAARQAAANAMALQAMALAeANQAdANARALQARALAKAMQALAOAGAPQAFAPAAAQQAAAngcAbQgdAcgoAAQgmAAgegVg");
	this.shape_11.setTransform(-2.7,-1.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhVCbIAAk1ICrAAIAAAqIiBAAIAABNICBAAIAAAqIiBAAIAABrICBAAIAAApg");
	this.shape_12.setTransform(-25.5,-1.6);

	this.instance_9 = new lib.Symbol19_1("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(-2.7,-3.2);

	this.instance_10 = new lib.Symbol24_1();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-1,-1.7);

	this.instance_11 = new lib.Symbol17_1();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-1.1,120.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.instance_8}]}).to({state:[{t:this.instance_11},{t:this.instance_10}]},1).wait(1));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A8WLGIAA2LMA4tAAAIAAWLg");
	mask_1.setTransform(-0.9,-0.2);

	// Layer 1
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000099").s().p("A3lH6IAAvzMAvLAAAIAAPzg");

	this.instance_12 = new lib.Symbol13_1();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-176.4,381.6);

	this.instance_13 = new lib.Symbol11_1();
	this.instance_13.parent = this;
	this.instance_13.setTransform(399.7,64.9,1,1,-0.1,0,0,0.1,0.1);

	this.instance_14 = new lib.Symbol9_1();
	this.instance_14.parent = this;
	this.instance_14.setTransform(174.5,-295.2,1,1,90);

	this.instance_15 = new lib.Symbol9_1();
	this.instance_15.parent = this;
	this.instance_15.setTransform(-399.1,-65.5);

	var maskedShapeInstanceList = [this.shape_13,this.instance_12,this.instance_13,this.instance_14,this.instance_15];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13}]}).to({state:[{t:this.shape_13},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-151,-50.5,302.1,101.1);


(lib.Symbol5copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol6copy3();
	this.instance.parent = this;
	this.instance.setTransform(0.1,-1.9);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5copy2, new cjs.Rectangle(-182.3,-73.2,363,142), null);


(lib.Symbol5copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol6copy2();
	this.instance.parent = this;
	this.instance.setTransform(0.1,-1.9);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5copy, new cjs.Rectangle(-182.3,-73.2,363,142), null);


(lib.Symbol5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance_1 = new lib.Symbol6_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.1,-1.9);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5_1, new cjs.Rectangle(-182.3,-73.2,363,142), null);


// stage content:
(lib.PDallbuttons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.movieClip_1 = new lib.Symbol5copy2();
	this.movieClip_1.parent = this;
	this.movieClip_1.setTransform(305.2,301.5,0.711,0.711);

	this.instance = new lib.Symbol5copy();
	this.instance.parent = this;
	this.instance.setTransform(182.2,195.2,0.711,0.711);

	this.instance_1 = new lib.Symbol6copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(430.7,193.9,0.71,0.71,0,0,0,0.3,0.2);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.instance_2 = new lib.Symbol5_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(430.3,92.6,0.711,0.711);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag5CvQgbgSgWgqIAegTQAhA9ArAAQASAAAQgIQARgJAIgPQAJgOAAgQQAAgTgMgSQgSgYgsgiQgvgigLgQQgUgaAAgeQAAgYAMgUQALgUAVgLQAWgLAXAAQAaAAAWANQAXAMAaAjIgfAXQgUgcgPgJQgOgIgSAAQgVAAgOANQgPAOAAATQABAMAFAMQAEALAOANQAHAHAnAeQAwAiASAcQARAbAAAcQAAAogeAdQgeAegrAAQghAAgcgSg");
	this.shape.setTransform(455.9,93.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag4CvQgbgSgYgqIAggTQAgA9ArAAQATAAAPgIQARgJAJgPQAIgOAAgQQAAgTgNgSQgRgYgtgiQgtgigMgQQgTgaAAgeQAAgYALgUQALgUAWgLQAUgLAYAAQAaAAAWANQAXAMAZAjIgeAXQgUgcgPgJQgPgIgRAAQgVAAgOANQgPAOAAATQAAAMAGAMQAEALAOANQAHAHAoAeQAvAiASAcQARAbAAAcQAAAogdAdQgfAegrAAQghAAgbgSg");
	this.shape_1.setTransform(430.4,93.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhpC4IAAlvIDTAAIAAAkIitAAIAAB0ICrAAIAAAjIirAAIAACQICrAAIAAAkg");
	this.shape_2.setTransform(406.5,93.4);

	this.instance_3 = new lib.Symbol5();
	this.instance_3.parent = this;
	this.instance_3.setTransform(182.2,92.6,0.711,0.711);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag5CvQgbgSgXgqIAggTQAgA9ArAAQASAAAQgIQARgJAIgPQAJgOAAgQQAAgTgMgSQgSgYgsgiQgugigMgQQgUgaAAgeQABgYALgUQALgUAWgLQAVgLAXAAQAaAAAWANQAXAMAaAjIgfAXQgUgcgPgJQgOgIgSAAQgVAAgOANQgPAOAAATQAAAMAGAMQAEALAOANQAHAHAnAeQAwAiASAcQARAbAAAcQAAAogeAdQgeAegrAAQghAAgcgSg");
	this.shape_3.setTransform(204.7,93.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag4CvQgbgSgYgqIAggTQAgA9ArAAQATAAAQgIQAQgJAJgPQAIgOAAgQQAAgTgNgSQgRgYgtgiQgtgigMgQQgTgaAAgeQAAgYALgUQALgUAWgLQAUgLAYAAQAaAAAWANQAXAMAZAjIgdAXQgWgcgOgJQgPgIgRAAQgVAAgOANQgOAOAAATQAAAMAEAMQAGALANANQAHAHAoAeQAvAiASAcQASAbgBAcQAAAogdAdQgfAegsAAQggAAgbgSg");
	this.shape_4.setTransform(179.2,93.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhpC4IAAlvIDTAAIAAAkIiuAAIAAB0ICsAAIAAAjIisAAIAACQICsAAIAAAkg");
	this.shape_5.setTransform(155.3,93.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.instance_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.movieClip_1}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(357.1,240.5,506.2,309.9);
// library properties:
lib.properties = {
	id: '6921DC55CC200D43A0DE06F06CD80047',
	width: 609,
	height: 400,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['6921DC55CC200D43A0DE06F06CD80047'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;